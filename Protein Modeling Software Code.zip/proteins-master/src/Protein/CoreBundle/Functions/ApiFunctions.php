<?php

namespace Protein\CoreBundle\Functions;

use Protein\CoreBundle\Entity\Upload;
use Protein\CoreBundle\Entity\Protein;
use Protein\CoreBundle\Entity\Species;

class ApiFunctions
{
        const PROTEIN_SEARCH_DATA = array(
                'id' => array(
                  'reference'=>false,
                  'types'=>array(
                    'default'=>'input',
                    'current'=>'default',
                    'input'=>array('type'=>'str', 'example'=>'A0A075CXE7'),
                    'list'=>false,
                    'range'=>false,
                  ),
                  'value'=> '',
                  'exact'=>false,
                ),
                'name' => array(
                  'reference'=>false,
                  'types'=>array(
                    'default'=>'input',
                    'current'=>'default',
                    'input'=>array('type'=>'str', 'example'=>'Mytilus edulis'),
                    'list'=>true,
                    'range'=>false,
                  ),
                  'value'=> '',
                  'exact'=>false,
                ),
                'gene'=>array(
                  'reference'=>false,
                  'types'=>array(
                    'default'=>'input',
                    'current'=>'list',
                    'input'=>array('type'=>'str', 'example'=>'MYTTR'),
                    'list'=>false,
                    'range'=>false,
                  ),
                  'value'=> '',
                  'exact'=>true,
                ),
                'len'=>array(
                  'reference'=>false,
                  'types'=>array(
                    'default'=>'input',
                    'current'=>'input',
                    'input'=>array('type'=>'float', 'example'=>183, 'min'=>0, 'max'=>5000000000),
                    'list'=>false,
                    'range'=>true,
                  ),
                  'value'=> '',
                  'exact'=>false,
                ),
                'qmean'=>array(
                  'reference'=>false,
                  'types'=>array(
                    'default'=>'input',
                    'current'=>'input',
                    'input'=>array('type'=>'float', 'example'=>0.07, 'min'=>-12, 'max'=>12),
                    'list'=>false,
                    'range'=>true,
                  ),
                  'value'=> '',
                  'exact'=>false,
                ),
                'qmean_norm'=>array(
                  'reference'=>false,
                  'types'=>array(
                    'default'=>'input',
                    'current'=>'input',
                    'input'=>array('type'=>'float', 'example'=>0.07, 'min'=>-12, 'max'=>12),
                    'list'=>false,
                    'range'=>true,
                  ),
                  'value'=> '',
                  'exact'=>false,
                ),
                'bonds'=>array(
                  'reference'=>false,
                  'types'=>array(
                    'default'=>'input',
                    'current'=>'input',
                    'input'=>array('type'=>'float', 'example'=>1100, 'min'=>0, 'max'=>5000000000),
                    'list'=>false,
                    'range'=>true,
                  ),
                  'value'=> '',
                  'exact'=>false,
                ),
                'bridges'=>array(
                  'reference'=>false,
                  'types'=>array(
                    'default'=>'input',
                    'current'=>'input',
                    'input'=>array('type'=>'float', 'example'=>123, 'min'=>0, 'max'=>5000000000),
                    'list'=>false,
                    'range'=>true,
                  ),
                  'value'=> '',
                  'exact'=>false,
                ),
                'species_name'=>array(
                  'reference'=>'Species',
                  'field'=>'species',
                  'ref_field'=>'name',
                  'types'=>array(
                    'default'=>'input',
                    'current'=>'input',
                    'input'=>array('type'=>'str', 'example'=>'Mytilus trossulus'),
                    'list'=>true,
                    'range'=>false,
                  ),
                  'value'=> '',
                  'exact'=>false,
                ),
                'pages_id'=>array(
                  'reference'=>'Page',
                  'field'=>'pages',
                  'ref_field'=>'id',
                  'types'=>array(
                    'default'=>'input',
                    'current'=>'input',
                    'input'=>array('type'=>'str', 'example'=>'5ba1d209b41d4'),
                    'list'=>true,
                    'range'=>false,
                  ),
                  'value'=> '',
                  'exact'=>false,
                ),
            );

    const INDEX_SEARCH_DATA = array(
            'filename' => array(
              'reference'=>false,
              'types'=>array(
                'default'=>'input',
                'current'=>'default',
                'input'=>array('type'=>'str', 'example'=>'1_100_4xtb.1.A_5adc5faca52be744e178f099'),
                'list'=>false,
                'range'=>false,
              ),
              'value'=> '',
              'exact'=>false,
            ),
            'organism_id' => array(
              'reference'=>false,
              'types'=>array(
                'default'=>'input',
                'current'=>'default',
                'input'=>array('type'=>'float', 'example'=>183, 'min'=>0, 'max'=>5000000000),
                'list'=>true,
                'range'=>false,
              ),
              'value'=> '',
              'exact'=>false,
            ),
            'UniProt' => array(
              'reference'=>false,
              'types'=>array(
                'default'=>'input',
                'current'=>'default',
                'input'=>array('type'=>'str', 'example'=>'Q9W5B9'),
                'list'=>false,
                'range'=>false,
              ),
              'value'=> '',
              'exact'=>false,
            ),
            'len'=>array(
              'reference'=>false,
              'types'=>array(
                'default'=>'input',
                'current'=>'input',
                'input'=>array('type'=>'float', 'example'=>183, 'min'=>0, 'max'=>5000000000),
                'list'=>false,
                'range'=>true,
              ),
              'value'=> '',
              'exact'=>false,
            ),
            'qmean'=>array(
              'reference'=>false,
              'types'=>array(
                'default'=>'input',
                'current'=>'input',
                'input'=>array('type'=>'float', 'example'=>0.07, 'min'=>-12, 'max'=>12),
                'list'=>false,
                'range'=>true,
              ),
              'value'=> '',
              'exact'=>false,
            ),
            'qmean_norm'=>array(
              'reference'=>false,
              'types'=>array(
                'default'=>'input',
                'current'=>'input',
                'input'=>array('type'=>'float', 'example'=>0.07, 'min'=>-12, 'max'=>12),
                'list'=>false,
                'range'=>true,
              ),
              'value'=> '',
              'exact'=>false,
            ),
            'bonds'=>array(
              'reference'=>false,
              'types'=>array(
                'default'=>'input',
                'current'=>'input',
                'input'=>array('type'=>'float', 'example'=>110, 'min'=>0, 'max'=>5000000000),
                'list'=>false,
                'range'=>true,
              ),
              'value'=> '',
              'exact'=>false,
            ),
            'bridges'=>array(
              'reference'=>false,
              'types'=>array(
                'default'=>'input',
                'current'=>'input',
                'input'=>array('type'=>'float', 'example'=>76, 'min'=>0, 'max'=>5000000000),
                'list'=>false,
                'range'=>true,
              ),
              'value'=> '',
              'exact'=>false,
            ),
            'species_name'=>array(
              'reference'=>'Species',
              'field'=>'species',
              'ref_field'=>'name',
              'types'=>array(
                'default'=>'input',
                'current'=>'input',
                'input'=>array('type'=>'str', 'example'=>'Mytilus trossulus'),
                'list'=>true,
                'range'=>false,
              ),
              'value'=> '',
              'exact'=>false,
            ),
        );

    public function __construct($em, $container)
    {
        $this->em = $em;
        $this->container = $container;
        $token = $container->get('security.token_storage')->getToken();
        $this->user = $token ? $token->getUser() : null;
    }

    public function getEntityPagination($page, $entity, $isJoin, $page_ind, $per_page, $pageParam) {
        $ent_repo = $this->em->getRepository($entity);
        $qb = $ent_repo->createQueryBuilder("ent");
        $qb->select("ent");
        if($page and $isJoin){
           $qb->innerJoin('ent.pages','pages')
              ->innerJoin('Core:Page', 'p', 'WITH','p.id = pages.id')
              ->where("p.id='" . $page->getId() . "'");
        }
        if($page and !$isJoin){
             $qb->where("ent.page='" . $page->getId() . "'");
        }

        $paginator  = $this->container->get('knp_paginator');
        $q = $qb->getQuery(); //->getArrayResult();
        $entity_collection = $paginator->paginate($q,  $page_ind, $per_page, array('pageParameterName'=>$pageParam));
        $pagination = $entity_collection->getPaginationData();
        $collection = array();
        $ids = array();
        foreach($entity_collection as $e){
            $collection[] = $e->serializeArray(); // Entity should implement serializeArray()
            #$ids[] = $e->getId();
        }
        #$pagination['ids'] = $ids;
        $pagination['pageParameterName'] = $pageParam;
    return array($collection, $pagination);
    }

    public function setProteinPage($prot_repo, $prot, $page){
        if(!$prot){ return; }

        $res = $prot_repo->createQueryBuilder("ent")
          ->select("ent.id")
          ->innerJoin('ent.pages','pages')
          ->innerJoin('Core:Page', 'p', 'WITH','p.id = pages.id')
          ->where("p.id='" . $page->getId() . "'")
          ->andWhere("ent.id='" . $prot->getId() . "'")
          ->setMaxResults( 1 )
          ->getQuery()->getArrayResult();

        if( count($res) == 0 ){
            $prot->addPage($page);
            $page->addProtein($prot);
            $this->em->persist($prot);
            $this->em->persist($page);
            $this->em->flush();
        }
    }


    public function setProteinIfNew($prot_repo, $current, $page){
        if( $prot=$prot_repo->find($current['UniProt'])){ 
            $this->setProteinPage($prot_repo, $prot, $page);

            $prot->setSequence($current['line']);
    
            if($current['gene'] and !$prot->getGene()){ $prot->setGene($current['gene']); }
            if($current['name'] and !$prot->getName()){ $prot->setName($current['name']); }
            if($current['species'] and !$prot->getSpecies()){ 
                $species = $this->em->getRepository('Core:Species')->findOneBy(array('name'=>$current['species']));
                $prot->setSpecies($species); 
            }
            $this->em->persist($prot);
            $this->em->flush();

            return $prot; 
        }

        $prt = new Protein();
        $prt->setId($current['UniProt']);
        $prt->setName($current['name']);
        $prt->setGene($current['gene']);
        $prt->setLen($current['len']);
        $prt->setSequence($current['line']);
        if( isset($current['species']) or isset($current['species_abbr']) ){
            $spec_repo = $this->em->getRepository('Core:Species');
            $spec = null;
            if(isset($current['species']) and !$spec = $spec_repo->findOneBy(array('name'=>$current['species']))){
            }
            if( !$spec and isset($current['species_abbr']) ){
                $spec = $spec_repo->findOneBy(array('abbr'=>$current['species_abbr']));
            }
            if(!$spec and isset($current['species'])){
                $spec = new Species();
                $spec->setName($current['species']);
                $spec->setAbbr(trim($current['species_abbr']));
                $this->em->persist($spec);
            }
            $prt->setSpecies($spec);
        }
        $prt->setQmean($current['qmean']);
        $prt->setQmeanNorm($current['qmean_norm']);
        $prt->setIndexRecord($current['record']);
        $prt->setFilename($current['filename']);
        $prt->addPage($page);
        $page->addProtein($prt);
        $this->em->persist($prt);
        $this->em->persist($page);
    return $prt;
    }


    public function parseFASTA($page, $filename, &$successes, &$errors, &$warnings){
        $prot_repo = $this->em->getRepository('Core:Protein');

        $fh = fopen($filename, 'r');
        if(!$fh){
            $errors[] = "Can not open the file";
            return false;
        }

        fgets($fh); 

        $i = 0;
        $ii = 0;
        while($line= fgets($fh)){
            $ii++;
            if( strpos($line, '>') === 0 ){
                if( isset($current['UniProt']) and $current['UniProt'] != ''){
                    $current['len'] = strlen($current['line']);
                    $this->setProteinIfNew($prot_repo, $current, $page);
                    $i++;
                    if( $i%100 < 2 ){
                        $this->em->flush();
                    }
                }
                if( strlen($line) < 6 ){ continue; }

                list($arrow, $UniProt, $names) = explode('|', $line);
                list($gene_abbr_name, $species_therest) = explode('OS=', $names);
                $protein_name = preg_replace("/^\w+\s+/",'', $gene_abbr_name);
                $gene_abbr = str_replace($protein_name, '', $gene_abbr_name);
                list($gene, $species_abbr) = explode('_', $gene_abbr);
                list($species, $therest) = explode('OX=', $species_therest);

                $current = array(
                    'UniProt'=>$UniProt,
                    'gene'=>$gene,
                    'name'=>$protein_name,
                    'species'=>$species,
                    'species_abbr'=>$species_abbr,
                    'line'=>'',
                    'len'=>null,
                    'qmean'=>null,
                    'qmean_norm'=>null, # we might insert those from pdb parsing
                    'filename'=>null,
                    'record'=>null,
                );

            }elseif( isset($current['UniProt']) ){
                $current['line'] .= $line;
            }
        }

        if( isset($current['UniProt']) ){
            $this->setProteinIfNew($prot_repo, $current, $page);
        }
        $this->em->flush();
        fclose($fh);
        unlink($filename);

        $successes["inserted_fasta_records_number"] = $i;
        $successes["lines"] = $ii;
        $successes["filename"] = $filename;
    }


    public function parsePDB($path, &$UniProt, &$gene, &$abbr, &$protein_name, &$qmean){
            # can be 
            #TITLE     SWISS-MODEL SERVER (https://swissmodel.expasy.org)
            #TITLE    2 Untitled Project

            # or can be
            #TITLE    2 A0A173FZD2_MYTTR A0A173FZD2 Cytochrome c oxidase subunit 1 # second line

            #REMARK   3  GMQE    0.75
            #REMARK   3  QMN4    -5.68

            #SOURCE   2 ORGANISM_SCIENTIFIC: CRAMBE HISPANICA SUBSP. ABYSSINICA;
            #SOURCE   3 ORGANISM_COMMON: ABYSSINIAN CRAMBE,ABYSSINIAN KALE;
            #SOURCE   4 ORGANISM_TAXID: 3721

            $file = file($path);

            $title_pattern_matched = false;
            $title_line = trim($file[1]);
            $arr = preg_split('/\s+/',$title_line);
            if( count($arr) > 5){
                array_shift($arr);
                array_shift($arr);
                $gene_abbr = array_shift($arr);
                if( strpos($gene_abbr, '_') !== false ){
                    list($gene, $abbr) = explode('_', $gene_abbr);
                    if($abbr){ 
                        $species = $this->em->getRepository('Core:Species')->findOneBy(array('abbr'=>$abbr));
                    } 
                    $UniProt = array_shift($arr);
                }else{
                    $UniProt = $gene_abbr;
                }
                $protein_name = implode(' ', $arr);
            }

            $qmean_lines = preg_grep('/REMARK\s+3\s+QMN4/', $file);
            if(count($qmean_lines)>0){
                $qmean = preg_replace('/.*\s+/', '', trim(current(array_filter($qmean_lines))));
            }

    return $title_pattern_matched;
    }


    public function registerPDB_upload_on_page($upload_repo, $page, $UniProt, $qmean, $savename, $record){
        if( $UniProt and $qmean 
                and $upload = $upload_repo->findOneBy(array('page'=>$page, 'UniProt'=>$UniProt, 'qmean'=>$qmean)) ){
            $upload->setAttempts( $upload->getAttempts() + 1 );
            $this->em->persist($upload);
        }else{
            $upload = new Upload();
            $upload->setUniProt($UniProt);
            $upload->setQmean($qmean);
            $upload->setFilename($savename);
            $upload->setIndexRecord($record);
            $upload->setPage($page);
            $this->em->persist($upload);
        }
        $this->em->flush();
    return $upload;
    }

    # will exit without registering pdb if qmean is not better then previous 
    public function collectPDB($page, $path, $filename, &$successes, &$errors, &$warnings){
        $protein = $UniProt = $gene = $species = $abbr = $protein_name = $len = $qmean = $qmean_norm = null;
        $proteinPDB = $UniProtPDB = $genePDB = $abbrPDB = $protein_namePDB = $qmeanPDB = null;
        $all_set = false;

        $index_repo = $this->em->getRepository('Core:Index');
        $prot_repo = $this->em->getRepository('Core:Protein');
        $upload_repo = $this->em->getRepository('Core:Upload');

        $fnm = preg_replace('/.*\//','', $filename);
        $filename_base = str_replace('.pdb', '', $fnm);
        $filename_base = str_replace('.PDB', '', $filename_base);
        $record = $index_repo->find($filename_base); // gives reference to UniProt and len, qmean of the pdb, organism_id

        $savefile = true;
        $savename = $fnm;
        if( file_exists("uploads/pdb/$fnm") ){
            $savename = $this->getNextAvailableFilename( "uploads/pdb/", $filename_base, '.pdb', $errors );
            $savename .= ".pdb";
        }

        # unlikely that pdb will contain title, but QMEAN usually is present
        # title parsing depends on automatic title from Swiss site
        $title_pattern_matched = $this->parsePDB($path, $UniProtPDB, $genePDB, $abbrPDB, $protein_namePDB, $qmeanPDB);
        if(!$qmeanPDB){
            // it's strange, but do nothing for now
        };
        # we should verify if UniProtPDB exists in any case
        if($title_pattern_matched and $UniProtPDB){
            $proteinPDB = $prot_repo->find($UniProtPDB);
            if($proteinPDB){

                # may have conflict with $genePDB, $abbrPDB, $protein_namePDB
                if(!$proteinPDB->getGene() and $genePDB){ 
                    $proteinPDB->setGene($genePDB); 
                }
                if(!$proteinPDB->getName() and $protein_namePDB){ 
                    $proteinPDB->setName($protein_namePDB); 
                }
                if(!$proteinPDB->getSpecies() and $speciesPDB){ 
                    $proteinPDB->setSpecies($speciesPDB); 
                }
                $this->em->persist($proteinPDB);
                $this->em->flush();

                # and $qmeanPDB could be not the best qmean for the protein -> exits
                $my_qmean = $protein->getQmean();
                if(!$my_qmean or $my_qmean <= $qmeanPDB){ 
                    $proteinPDB->setQmean($qmeanPDB); 
                    $proteinPDB->setFilename($savename);
                    $this->em->persist($proteinPDB);
                    $this->em->flush();
                }elseif($my_qmean and $qmeanPDB and $my_qmean > $qmeanPDB){ 
                    $this->setProteinPage($prot_repo, $proteinPDB, $page);
                    $this->registerPDB_upload_on_page($upload_repo, $page, $UniProtPDB, $qmeanPDB, $savename, $record);
                    $errors[] = "Current PDB has better Qmean: $my_qmean > $qmeanPDB";
                    return false;
                }
            }else{
                $proteinPDB = new Protein();
                $proteinPDB->setId($UniProtPDB);
                $proteinPDB->setName($protein_namePDB);
                $proteinPDB->setGene($genePDB);
                $proteinPDB->setSpecies($speciesPDB);
                $proteinPDB->setQmean($qmeanPDB);
                $proteinPDB->setFilename($savename);
                $this->em->persist($proteinPDB);
                $this->em->flush();

                $savefile = true;
            }
            $this->setProteinPage($prot_repo, $proteinPDB, $page);
            $upload = $this->registerPDB_upload_on_page($upload_repo, $page, $UniProtPDB, $qmeanPDB, $savename, $record);
            $all_set = true;
        }

        # file name can not be both UniProt and filename from Index
        if( $record ){ 
            # record can exist without protein in db
            # but we will create one even if not

            $UniProt = $record->getUniProt();
            $len = $record->getLen();
            $qmean = $record->getQmean();
            $qmean_norm = $record->getQmeanNorm();

            if($proteinPDB){ 
                if($UniProt != $UniProtPDB){
                    $errors[] = "Something is deeply wrong, conflicting UniProts in $filename: '$UniProt' != '$UniProtPDB'";
                    return false;
                }
                $protein = $proteinPDB;
            }else{
                $protein = $prot_repo->find($UniProt);
            }

            if($qmean != $qmeanPDB){
                if(!$all_set){
                    $this->setProteinPage($prot_repo, $protein, $page);
                    $this->registerPDB_upload_on_page($upload_repo, $page, $UniProt, $qmean, $savename, $record);
                }
                $errors[] = "Something is deeply wrong, conflicting qmeans in the record and $filename: '$qmean' != '$qmeanPDB'";
                return false;
            }

            if( $protein ){
                $protein->setIndexRecord($record);
                if(!$protein->getLen()){ 
                    $protein->setLen($len); 
                }

                $my_qmean = $protein->getQmean();
                if(!$my_qmean or $my_qmean <= $qmean){
                    $protein->setQmean($qmean);
                    $protein->setQmeanNorm($qmean_norm);
                    $protein->setFilename($savename);
                    $this->em->persist($protein);
                    $this->em->flush();
                }elseif($my_qmean and $qmean and $qmean < $my_qmean){

                    if(!$all_set){
                        $this->setProteinPage($prot_repo, $protein, $page);
                        $this->registerPDB_upload_on_page($upload_repo, $page, $UniProt, $qmean, $savename, $record);
                    }
                    $errors[] = "Current PDB has better Qmean: $my_qmean > $qmean";
                    return false;
                }
            }else{
                // also means there was no $proteinPDB
                $protein = new Protein();
                $protein->setId($UniProt);
                $protein->setQmean($qmean);
                $protein->setQmeanNorm($qmean_norm);
                $protein->setFilename($savename);
                $protein->setIndexRecord($record);
                $this->em->persist($protein);
                $this->em->flush();
            }

            if(!$all_set){
                $this->setProteinPage($prot_repo, $protein, $page);
                $upload = $this->registerPDB_upload_on_page($upload_repo, $page, $UniProt, $qmean, $savename, $record);
                $all_set = true;
            }
            $savefile = true;
        }

        # file name can not be both UniProt and filename from Index
        # try name as UniProt only as last resort
        if(!$protein and !$proteinPDB and strlen($filename_base) < 15){
            $protein = $prot_repo->find($filename_base);
            if($protein){

                if(!$all_set){
                    $this->setProteinPage($prot_repo, $protein, $page);
                    $upload = $this->registerPDB_upload_on_page($upload_repo, $page, $filename_base, $qmeanPDB, $savename, null);
                }

                $my_qmean = $protein->getQmean();
                if(!$my_qmean or $my_qmean < $qmeanPDB){
                    $protein->setQmean($qmeanPDB);
                    $protein->setFilename($savename);
                    $this->em->persist($protein);
                    $this->em->flush();
                }else{
                    $errors[] = "Current PDB has better Qmean";
                    return false;
                }
            }
        }

        # if still nothing, leave
        if(!$protein){ 
            $errors[] = "Not able to Identify UniProt $filename";
            $this->registerPDB_upload_on_page($upload_repo, $page, null, $qmeanPDB, $savename, null);
            # maybe still move the file?
            return false;
        }

        # saving file
        if( $savefile and !rename($path, "uploads/pdb/$savename") ){
            $errors[] = "Not able to move file to uploads/pdb folder";
        }

        $successes[] = array(
            'protein'=>$protein->serializeArray(),
            'upload'=>$upload->serializeArray(),
            'file'=>$filename,
        );

    return true;
    }

    public function addProteinToPage($prot_repo, $page, $protein, $UniProt){
        // since all inserts are unique, flush delay should not be a problem win db sync here

        if(!$protein){ return; }
        $res = $prot_repo->createQueryBuilder("ent")
          ->select("ent.id")
          ->innerJoin('ent.pages','pages')
          ->innerJoin('Core:Page', 'p', 'WITH','p.id = pages.id')
          ->where("p.id='" . $page->getId() . "'")
          ->andWhere("ent.id='" . $protein->getId() . "'")
          ->setMaxResults( 1 )
          ->getQuery()->getArrayResult();

        if( count($res) == 0 ){
            $protein->addPage($page);
            $page->addProtein($protein);
            $this->em->persist($protein);
            $this->em->persist($page);
        }
    }


    public function recordsToProts($recs, &$prots, &$uploads){
        foreach($recs as $rec){
            $unp = $rec['UniProt'];
            $uploads[$rec['filename']]['UniProt'] = $unp;
            $uploads[$rec['filename']]['qmean'] = $rec['qmean'];

            if( !isset($prots[$unp]) ){
                $prots[$unp] = $rec;
                continue;
            }
            if(is_null($rec['qmean'])){
                continue;
            }
            if(is_null($prots[$unp]['qmean']) or $rec['qmean'] > $prots[$unp]['qmean']){
                $prots[$unp] = $rec;
            }
        }
    }

    public function collectPDBzip($page, $path, $logfile, &$stats){
        $protein = $UniProt = $gene = $species = $abbr = $protein_name = $len = $qmean = $qmean_norm = null;
        $slug  = $page->getId();

        $index_repo = $this->em->getRepository('Core:Index');
        $prot_repo = $this->em->getRepository('Core:Protein');
        $upload_repo = $this->em->getRepository('Core:Upload');

        $files = scandir($path);
        $data = array();
        $lost = array();

        $stats['start'] = date("Y-m-d H:i:s");
        $stats['total'] = count($files) - 2; // -2 for dots
        $stats['low'] = 0;
        $stats['low_db'] = 0;
        $stats['not_found'] = 0;

        $filenames = array();
        $uploads = array();
        foreach ($files as $fn) {
            if ($fn == "." or $fn == "..") {
                continue;
            }
            $fnm = preg_replace('/.*\//','', $fn);
            $fnm = str_replace('.PDB', '', str_replace('.pdb', '', $fnm));
            $filenames[] = $fnm;
            $uploads[$fnm] = array('file'=>$fn);
        }
        unset($files);

        $filenames = array_chunk($filenames, 100);

        $prots = array();
        $prots_no_rec = array();

        foreach($filenames as $chunk){
            # filename for retriving record below
            $rec_prot_list = $index_repo->createQueryBuilder("rc")
              ->select("rc.filename, rc.UniProt, rc.organism_id, rc.qmean, rc.qmean_norm, rc.len, pr.qmean as prot_qmean") 
              ->innerJoin('Core:Protein', 'pr', 'WITH','pr.id = rc.UniProt')
              ->where("rc.filename IN (:mylist)")
              ->setParameter('mylist', $chunk, \Doctrine\DBAL\Connection::PARAM_STR_ARRAY)
              ->getQuery()->getArrayResult();
            $rec_with_prot_list = array_column($rec_prot_list, 'filename');
            $reduced_chunk = array_diff($chunk, $rec_with_prot_list);
            foreach($rec_prot_list as &$r){ $r['has_protein'] = true; }

            $rec_left = $index_repo->createQueryBuilder("rc")
              ->select("rc.filename, rc.UniProt, rc.organism_id, rc.qmean, rc.qmean_norm, rc.len") # filename for retriving record below
              ->where("rc.filename IN (:mylist)")
              // ->andWhere("rc.filename NOT IN (:notlist)")
              ->setParameter('mylist', $reduced_chunk, \Doctrine\DBAL\Connection::PARAM_STR_ARRAY)
              //->setParameter('notlist', $rec_with_prot_list, \Doctrine\DBAL\Connection::PARAM_STR_ARRAY)
              ->getQuery()->getArrayResult();
            $rec_without_prot_list = array_column($rec_left, 'filename');

            $recs = array_merge($rec_prot_list, $rec_left);
//$prev_prots_count = count($prots);
            $this->recordsToProts($recs, $prots, $uploads);
// var_dump('chunk', $chunk);
// var_dump('list', $rec_with_prot_list);
// var_dump('reduced chunk', $reduced_chunk);
// var_dump('left', $rec_without_prot_list);
//var_dump('Records vs prots:', count($chunk), count($recs), count($prots)-$prev_prots_count, "***", count($rec_with_prot_list), count($reduced_chunk), count($rec_without_prot_list), "***");
        }

        file_put_contents($logfile, 40);

var_dump('Final prots and uploads from files:',  count($prots), count($uploads), $stats['total']);

        $stats['unique_proteins'] = count($prots);
        $stats["Lost"] = 0;
        $stats["not_moved"] = 0;

        $flush_count = 0;
        $errors = array();
        $spec_repo = $this->em->getRepository('Core:Species');

        foreach ($prots as $UniProt=>$d) {

            $fnm = $d['filename'];
            $filename = $uploads[$fnm]['file'];

            if(!file_exists("$path/$filename")){
                $lost[] = $filename;
                $stats["Lost"]++;
                continue;
            }

            $savename = $filename; // for uploads detected in INDEX record don't change
            // change the name for files not from index if it's taken, don't override, but for indexed override is fine
            /* if( file_exists("uploads/pdb/$filename") ){
                $savename = $this->getNextAvailableFilename( "uploads/pdb/", $fnm, '.pdb', $errors );
                $savename .= ".pdb";
            }*/
            if( !rename("$path/$filename", "uploads/pdb/$savename") ){
                $stats["not_moved"]++;
            } 
            $uploads[$fnm]['savename'] = $savename;

            if(isset($d['prot_qmean']) and !is_null($d['qmean']) and $d['prot_qmean'] > $d['qmean']){ 
                # just set the page (so it will display protein, even though with different data -- better qmean)
                $same_prot = $prot_repo->find($UniProt);
                $this->addProteinToPage($prot_repo, $page, $same_prot, $UniProt);

                $flush_count++;
                if($flush_count > 1000){
                    $this->em->flush();
                    $this->em->clear();
                    $prot_repo = $this->em->getRepository('Core:Protein');
                    $spec_repo = $this->em->getRepository('Core:Species');
                    $page = $this->em->getRepository('Core:Page')->find($slug);
                    $flush_count=0;
                }

                continue; 
            }

            // has protein only prevents additional query if no protein
            if(isset($d['has_protein']) and $protein = $prot_repo->find($UniProt)){
                // do not create new one
            }else{
                $protein = new Protein();
                $protein->setId($UniProt);
            }
            $protein->setLen($d['len']); 
            $protein->setQmean($d['qmean']);
            $protein->setQmeanNorm($d['qmean_norm']);
            $protein->setFilename($savename);

            $organism = $spec_repo->findOneBy(array('organism_id'=>$d['organism_id']));
            $protein->setSpecies($organism);

            $protein->setBonds(null); # will need to recalculate since it's new pdb file with better qmean
            $protein->setBridges(null); 

            $record = $index_repo->find($d['filename']);
            $protein->setIndexRecord($record);

            $this->em->persist($protein);

            $this->addProteinToPage($prot_repo, $page, $protein, $UniProt);

            $flush_count++;
            if($flush_count > 1000){
                $this->em->flush();
                $this->em->clear();
                $prot_repo = $this->em->getRepository('Core:Protein');
                $spec_repo = $this->em->getRepository('Core:Species');
                $page = $this->em->getRepository('Core:Page')->find($slug);
                $organism = $this->em->getRepository('Core:Species')->findOneBy(array('organism_id'=>$d['organism_id']));
                $flush_count=0;
            }
        }
        $this->em->flush();
        unset($prots);


        $stats['start_files'] = date("Y-m-d H:i:s");

        $upload_repo = $this->em->getRepository('Core:Upload');

        $flush_count=0;
        foreach($uploads as $fnm => $u){
            // $upload = $this->registerPDB_upload_on_page($upload_repo, $page, $UniProt, $qmean, $savename, $record);
            if( $upload = $upload_repo->findOneBy(array('page'=>$page, 'filename'=>$u['file'])) ){
                $upload->addAttempt();
                $this->em->persist($upload);
                $flush_count++;

                $flush_count++;
                if($flush_count > 1000){
                    $this->em->flush();
                    $this->em->clear();
                    $upload_repo = $this->em->getRepository('Core:Upload');
                    $page = $this->em->getRepository('Core:Page')->find($slug);
                    opcache_reset();
                    $flush_count=0;
                }

                continue;
            }

            $upload = new Upload();
            $upload->setType('pdb');
            $upload->setFilename($u['file']);
            $upload->setSavename(isset($u['savename']) ? $u['savename'] : null);
            if(isset($u['UniProt']) and $record = $index_repo->find($fnm)){ 
                $upload->setIndexRecord($record);
                $upload->setUniProt($u['UniProt']);
                $upload->setQmean($u['qmean']);
            }
            $upload->setPage($page);
            $this->em->persist($upload);

            $flush_count++;
            if($flush_count > 1000){
                $this->em->flush();
                $this->em->clear();
                $upload_repo = $this->em->getRepository('Core:Upload');
                $page = $this->em->getRepository('Core:Page')->find($slug);
                opcache_reset();
                $flush_count=0;
            }
        }
        $this->em->flush();
        $stats['stop'] = date("Y-m-d H:i:s");

    return true;
    }


    public function speciesSearch( $subpage_ind, $per_page, &$successes, &$errors, &$warnings )
    {
        $params = isset($_POST['search']) ? $_POST['search'] : array();
        $cols = array(
                'name' => array(
                  'reference'=>false,
                  'types'=>array(
                    'default'=>'input',
                    'current'=>'default',
                    'input'=>array('type'=>'str', 'example'=>'Mytilus edulis'),
                    'list'=>true,
                    'range'=>false,
                  ),
                  'value'=> '',
                  'exact'=>false,
                ),
                'abbr'=>array(
                  'reference'=>false,
                  'types'=>array(
                    'default'=>'input',
                    'current'=>'list',
                    'input'=>array('type'=>'str', 'example'=>'MYTTR'),
                    'list'=>true,
                    'range'=>false,
                  ),
                  'value'=> '',
                  'exact'=>true,
                ),
                'protein_UniProtID'=>array(
                  'reference'=>'Protein',
                  'field'=>'proteins',
                  'ref_field'=>'id',
                  'types'=>array(
                    'default'=>'input',
                    'current'=>'input',
                    'input'=>array('type'=>'str', 'example'=>'A0A021WW32'),
                    'list'=>false,
                    'range'=>false,
                  ),
                  'value'=> '',
                  'exact'=>false,
                ),
                'protein_QMEAN'=>array(
                  'reference'=>'Protein',
                  'field'=>'proteins',
                  'ref_field'=>'qmean',
                  'types'=>array(
                    'default'=>'input',
                    'current'=>'input',
                    'input'=>array('type'=>'float', 'example'=>0.07, 'min'=>-12, 'max'=>12),
                    'list'=>false,
                    'range'=>true,
                  ),
                  'value'=> '',
                  'exact'=>false,
                )
            );

        $search = array();
        foreach( $params as $item ){
            if( !isset($item['col']) or !isset($cols[$item['col']]) ){
                $errors[] = "Either no name for column or column don't exist";
                return array($cols, null, null, null, null);
            }
            $col = $item['col'];
            if( !isset($search[$col]) ){
                $search[$col] = array();
            }
            $search[$col][] = $item;
        }
        $arr = array();
        foreach($search as $items){ $arr += $items; }

        $ent_repo = $this->em->getRepository('Core:Species');
        $qb = $ent_repo->createQueryBuilder("ent");
        $qb->select("ent");
        $first_where = true;

        foreach($search as $col=>$items){
            $ref = $cols[ $col ]['reference'];
            if($ref){
               $my_field = $cols[ $col ]['field'];
               $ref_field = $cols[ $col ]['ref_field'];
               $qb->innerJoin("ent.$my_field", 'collection')
                  ->innerJoin("Core:$ref", 'r', 'WITH', 'r.id = collection.id');
            }
            foreach($items as $item){
                $field = ($ref) ? "r.$ref_field" : "ent.$col";
                if(isset($item['exact'])){
                    $subquery = "$field = :val";
                }elseif(isset($item['contains'])){
                    $subquery = "$field LIKE :val";
                    // $subquery = $qb->expr()->notLike($field, ':val');
                }elseif(isset($item['min']) and isset($item['max'])){
                    $subquery = "$field BETWEEN :min AND :max"; 
                }
                // $subquery = $qb->expr()->not($subquery);

                if($first_where){
                    $qb->where($subquery);
                    $first_where = false;
                }else if($item['bool'] == 'And'){
                    $qb->andWhere($subquery);
                }else if($item['bool'] == 'Or'){
                    $qb->orWhere($subquery);
                }

                if(isset($item['exact'])){
                    $qb->setParameter('val', "{$item['exact']}");
                }else if(isset($item['contains'])){
                    $qb->setParameter('val', "%{$item['contains']}%");
                }elseif(isset($item['min']) and isset($item['max'])){
                    $qb->setParameter('min', $item['min']);
                    $qb->setParameter('max', $item['max']);
                }
            }
            $qb->groupBy('ent.id');
            //$q = $qb->getQuery()->getDQL();
            //var_dump($q);
            //$res = $qb->getQuery()->getArrayResult();
            //var_dump($res);
        }

        list($proteins, $pagination) = $this->getEntityPaginationQB(
            $qb,
            $subpage_ind,
            $per_page,
            'indexPage');


    return array($cols, $search, $arr, $proteins, $pagination);
    }


    public function proteinSearch( $post_search, &$successes, &$errors, &$warnings )
    {
        $cols = self::PROTEIN_SEARCH_DATA;
    return $this->genericSearch('Protein', 'id', 'ent.id ASC, ent.qmean DESC', $cols, $post_search, $successes, $errors, $warnings );
    }


    public function indexSearch( $post_search, &$successes, &$errors, &$warnings )
    {
        $cols = self::INDEX_SEARCH_DATA;
    return $this->genericSearch('Index', 'filename', 'ent.UniProt ASC, ent.qmean DESC', $cols, $post_search, $successes, $errors, $warnings );
    }

    public function genericSearch( $entity_name, $groupByID, $order, $cols, $post_search, &$successes, &$errors, &$warnings )
    {
        if( !$post_search ){
            return array($cols, null, null, null);
        }

        $search = array();
        foreach( $post_search as $item ){
            if( !isset($item['col']) or !isset($cols[$item['col']]) ){
                $errors[] = "Either no name for column or column don't exist";
                return array($cols, null, null, null);
            }
            $col = $item['col'];
            if( !isset($search[$col]) ){
                $search[$col] = array();
            }
            $search[$col][] = $item;
        }
        $arr = array();
        foreach($search as $items){ $arr = array_merge( $arr, $items ); }

        $ent_repo = $this->em->getRepository("Core:$entity_name");
        $qb = $ent_repo->createQueryBuilder("ent");
        $qb->select("ent");

        #var_dump($search, "<BR>");

        $first_where = true;
        foreach($search as $col=>$items){
            $ref = $cols[ $col ]['reference'];
            if($ref){
               $my_field = $cols[ $col ]['field'];
               $ref_field = $cols[ $col ]['ref_field'];
               $qb->innerJoin("ent.$my_field", 'collection')
                  ->innerJoin("Core:$ref", 'r', 'WITH', 'r.id = collection.id');
            }
            $field = ($ref) ? "r.$ref_field" : "ent.$col";
            $param = ($ref) ? "r_$ref_field" : "ent_$col";

            #var_dump($col, $items, "<BR>");

            foreach($items as $item){
                #var_dump(">>>",  $item, "<BR>");
                if(isset($item['exact'])){
                    $qb->setParameter($param, "{$item['exact']}");
                    $subquery = "$field = :$param";
                }elseif(isset($item['contains'])){
                    $qb->setParameter($param, "%{$item['contains']}%");
                    $subquery = "$field LIKE :$param";
                    // $subquery = $qb->expr()->notLike($field, ':param');
                }elseif(isset($item['min']) and isset($item['max'])){
                    $qb->setParameter("from_$param", $item['min']);
                    $qb->setParameter("to_$param", $item['max']);
                    #$subquery = $qb->expr()->between($field, ":from_$param", ":to_$param");
                    $subquery = "$field BETWEEN :from_$param AND :to_$param"; 
                }

                if(isset($item['NOT'])){ #inverse subquery
                    $subquery = $qb->expr()->not($subquery);
                }

                if($first_where){
                    $qb->where($subquery);
                    $first_where = false;
                }else if($item['bool'] == 'And'){
                    $qb->andWhere($subquery);
                }else if($item['bool'] == 'Or'){
                    $qb->orWhere($subquery);
                }
            }
        }
        $qb->groupBy("ent.$groupByID"); // 'id' or 'filename'
        $qb->add('orderBy', $order);

        //$q = $qb->getQuery()->getDQL();
        //var_dump($q);
        //var_dump("<BR>");
        //$res = $qb->getQuery()->getArrayResult();
        //var_dump($res);

    return array($cols, $search, $arr, $qb);
    }

    public function getEntityPaginationQB($qb, $page_ind, $per_page, $pageParam) {
        $paginator  = $this->container->get('knp_paginator');
        $q = $qb->getQuery(); //->getArrayResult();
        $entity_collection = $paginator->paginate($q,  $page_ind, $per_page, array('pageParameterName'=>$pageParam));
        $pagination = $entity_collection->getPaginationData();
        $collection = array();
        $ids = array();
        foreach($entity_collection as $e){
            $collection[] = $e->serializeArray(); // Entity should implement serializeArray()
            #$ids[] = $e->getId();
        }
        #$pagination['ids'] = $ids;
        $pagination['pageParameterName'] = $pageParam;
    return array($collection, $pagination);
    }



    ///////////////////////////////////////////////////
    ///////////////////////////////////////////////////
    //////////////     Upload functions     ///////////
    ///////////////////////////////////////////////////
    ///////////////////////////////////////////////////

    public function fileDrop($file_type, &$errors){
       if (!empty($_FILES)){
            foreach ($_FILES as $file) {
                if ($file['error'] != 0) {
                    $errors[] = array( 'text'=>'File error', 'error'=>$file['error'], 'name'=>$file['name']);
                    continue;
                }
                if(!$file['tmp_name']){
                    $errors[] = array( 'text'=>'Tmp file not found', 'name'=>$file['name']);
                    continue;
                }
                $tmp_file_path = $file['tmp_name'];
                $filename =  (isset($file['filename']) )? $file['filename'] : $file['name'];
                if( isset($_POST['dzuuid'])){
                    $chunks_res = $this->resumableUpload($tmp_file_path, $filename);
                    $chunks_res['name'] = $filename;
                    return $chunks_res;
                }

                # if not from chunks, move file
                $rel_path = "uploads/whole_from_chunks/";
                $info = pathinfo($filename);
                $extension = isset($info['extension'])? '.'.strtolower($info['extension']) : '';
                $filenameInf = $info['filename'];

                $saveName = $this->getNextAvailableFilename( $rel_path, $filenameInf, $extension, $errors );
                if( $saveName and !rename($tmp_file_path, "$rel_path$saveName$extension") ){
                    $errors[] = "Not able to move file to uploads/pdb folder";
                    continue;
                }
                $file_path = "$rel_path$saveName$extension";
                return array('final'=>true, 'path'=>$file_path, 'name'=>$filename);
             }
        }
    return false;
    }


    public function resumableUpload($tmp_file_path, $filename){
        $successes = array();
        $errors = array();
        $warnings = array();
        $dir = "uploads/tmp/";
            $identifier = ( isset($_POST['dzuuid']) )?  trim($_POST['dzuuid']) : '';
            $file_chunks_folder = "$dir$identifier";
            if (!is_dir($file_chunks_folder)) {
                mkdir($file_chunks_folder, 0777, true);
            }
            $filename = str_replace( array(' ','(', ')' ), '_', $filename ); # remove problematic symbols
            $info = pathinfo($filename);
            $extension = isset($info['extension'])? '.'.strtolower($info['extension']) : '';
            $filename = $info['filename'];
            $totalSize =   (isset($_POST['dztotalfilesize']) )?    (int)$_POST['dztotalfilesize'] : 0;
            $totalChunks = (isset($_POST['dztotalchunkcount']) )?  (int)$_POST['dztotalchunkcount'] : 0;
            $chunkInd =  (isset($_POST['dzchunkindex']) )?         (int)$_POST['dzchunkindex'] : 0;
            $chunkSize = (isset($_POST['dzchunksize']) )?          (int)$_POST['dzchunksize'] : 0;
            $startByte = (isset($_POST['dzchunkbyteoffset']) )?    (int)$_POST['dzchunkbyteoffset'] : 0;
            $chunk_file = "$file_chunks_folder/{$filename}.part{$chunkInd}";
            if (!move_uploaded_file($tmp_file_path, $chunk_file)) {
                $errors[] = array( 'text'=>'Move error', 'name'=>$filename, 'index'=>$chunkInd );
            }
            if( count($errors) == 0 and $new_path = $this->checkAllParts(  $file_chunks_folder,
                                                                    $filename,
                                                                    $extension,
                                                                    $totalSize,
                                                                    $totalChunks,
                                                                    $successes, $errors, $warnings) and count($errors) == 0){
                return array('final'=>true, 'path'=>$new_path, 'successes'=>$successes, 'errors'=>$errors, 'warnings' =>$warnings);
            }
    return array('final'=>false, 'successes'=>$successes, 'errors'=>$errors, 'warnings' =>$warnings);
    }

    public function checkAllParts( $file_chunks_folder,
                            $filename,
                            $extension,
                            $totalSize,
                            $totalChunks,
                            &$successes, &$errors, &$warnings){
        // reality: count all the parts of this file
        $parts = glob("$file_chunks_folder/*");
        $successes[] = count($parts)." of $totalChunks parts done so far in $file_chunks_folder";
        // check if all the parts present, and create the final destination file
        if( count($parts) == $totalChunks ){
            $loaded_size = 0;
            foreach($parts as $file) {
                $loaded_size += filesize($file);
            }
            if ($loaded_size >= $totalSize and $new_path = $this->createFileFromChunks(
                                                            $file_chunks_folder,
                                                            $filename,
                                                            $extension,
                                                            $totalSize,
                                                            $totalChunks,
                                                            $successes, $errors, $warnings) and count($errors) == 0){
                $this->cleanUp($file_chunks_folder);
                return $new_path;
            }
        }
    return false;
    }

    /**
     * Check if all the parts exist, and
     * gather all the parts of the file together
     * @param string $file_chunks_folder - the temporary directory holding all the parts of the file
     * @param string $fileName - the original file name
     * @param string $totalSize - original file size (in bytes)
     */
    public function createFileFromChunks($file_chunks_folder, $fileName, $extension, $total_size, $total_chunks,
                                            &$successes, &$errors, &$warnings) {
        $rel_path = "uploads/whole_from_chunks/";
        $saveName = $this->getNextAvailableFilename( $rel_path, $fileName, $extension, $errors );
        if( !$saveName ){
            return false;
        }
        $fp = fopen("$rel_path$saveName$extension", 'w');
        if ($fp === false) {
            $errors[] = 'cannot create the destination file';
            return false;
        }
        for ($i=0; $i<$total_chunks; $i++) {
            fwrite($fp, file_get_contents($file_chunks_folder.'/'.$fileName.'.part'.$i));
        }
        fclose($fp);
        return "$rel_path$saveName$extension";
    }

    public function getNextAvailableFilename( $rel_path, $orig_file_name, $extension, &$errors ){
        if( file_exists("$rel_path$orig_file_name$extension") ){
            $i=0;
            while(file_exists("$rel_path{$orig_file_name}_".(++$i).$extension) and $i<10000){}
            if( $i >= 10000 ){
                $errors[] = "Can not create unique name for saving file $orig_file_name$extension";
                return false;
            }
        return $orig_file_name."_".$i;
        }
    return $orig_file_name;
    }


    function rrmdir($dir) {
        if (is_dir($dir)) {
            $objects = scandir($dir);
            foreach ($objects as $object) {
                if ($object != "." && $object != "..") {
                    if (filetype("$dir/$object") == "dir") {
                        $this->rrmdir("$dir/$object");
                    } else {
                        unlink("$dir/$object");
                    }
                }
            }
            reset($objects);
            rmdir($dir);
        }
    }

    public function cleanUp($file_chunks_folder){
        // rename the temporary directory (to avoid access from other concurrent chunks uploads) and than delete it
        if (rename($file_chunks_folder, $file_chunks_folder.'_UNUSED')) {
            $this->rrmdir($file_chunks_folder.'_UNUSED');
        } else {
            $this->rrmdir($file_chunks_folder);
        }
    }

}
