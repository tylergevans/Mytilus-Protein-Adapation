<?php

namespace Protein\CoreBundle\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Output\OutputInterface;

use Protein\CoreBundle\Entity\Protein;
use Protein\CoreBundle\Entity\Species;

class DeleteEmptyPagesCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('app:pages')
            ->addArgument('com', InputArgument::OPTIONAL, 'Different command?')
            ->addArgument('slug', InputArgument::OPTIONAL, 'Page slug?')
            ->setDescription('Command to delete empty pages')
            ->setHelp('Use as command to delete empty pages older then 1h');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $container = $this->getContainer();
        $api_fn = $container->get('api_functions');
        $em = $container->get('doctrine')->getManager();

        $com = $input->getArgument('com');
        $slug = $input->getArgument('slug');

        if(!$com and !$slug){
            $this->deleteEmptyPages($em, $output);
        }elseif($com == 'delete'){
            $this->deletePage($em, $output, $slug);
        }
        opcache_reset();
        $output->writeln("Done!");
    }

    public function deletePage($em, $output, $slug){
        $page_repo = $em->getRepository('Core:Page');
        if(!$page = $page_repo->find($slug)){
            $output->writeln("No page $slug found!");
            return;
        }
        $em->remove($page);
        $em->flush();
    }

    public function deleteEmptyPages($em, $output){
        $page_repo = $em->getRepository('Core:Page');
        $proteins_repo = $em->getRepository('Core:Protein');
        $amino_repo = $em->getRepository('Core:Amino');
        $uploads_repo = $em->getRepository('Core:Upload');

        $pages_query = $page_repo->createQueryBuilder("p")
                ->select("p.id, p.createdAt");
        $pages = $pages_query->getQuery()->getArrayResult();

        $hour_ago = new \DateTime();
        $hour_ago->modify('-1 hour');

        $pages_to_delete_ids = Array();

        foreach( $pages as &$page ){
            $proteins_rec = $proteins_repo->createQueryBuilder("pr")
              ->select("pr.id")
              ->innerJoin('pr.pages','pages')
              ->innerJoin('Core:Page', 'p', 'WITH','p.id = pages.id')
              ->where("p.id='{$page['id']}'")
              ->setMaxResults( 1 )
              ->getQuery()->getArrayResult();
            $page['proteins'] = count($proteins_rec);
            $amino_rec = $amino_repo->createQueryBuilder("a")
              ->select("a.id")
              ->innerJoin('a.pages','pages')
              ->innerJoin('Core:Page', 'p', 'WITH','p.id = pages.id')
              ->where("p.id='{$page['id']}'")
              ->setMaxResults( 1 )
              ->getQuery()->getArrayResult();
            $page['amino'] = count($amino_rec);
            $upload_rec = $uploads_repo->createQueryBuilder("u")
              ->select("u.id")
              ->innerJoin('Core:Page', 'p', 'WITH','p.id = u.page')
              ->where("p.id='{$page['id']}'")
              ->setMaxResults( 1 )
              ->getQuery()->getArrayResult();
            $page['uploads'] = count($upload_rec);
            if( $page['proteins'] < 1 and $page['amino'] < 1 and $page['uploads'] < 1 and  $hour_ago > $page['createdAt']){
                    $pages_to_delete_ids[] = $page['id'];
                    continue;
            }
        }
        foreach($pages_to_delete_ids as $page_id){ $em->remove($page_repo->find($page_id)); }
        $em->flush();
    }
}
