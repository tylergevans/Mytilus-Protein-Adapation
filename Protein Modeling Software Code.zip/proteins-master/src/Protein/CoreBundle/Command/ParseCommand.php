<?php

namespace Protein\CoreBundle\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Output\OutputInterface;

use Protein\CoreBundle\Entity\Index;

class ParseCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('app:parse-index')
            ->addArgument('path', InputArgument::REQUIRED, 'The path to file.')
            ->setDescription('Command to parse Swiss INDEX file')
            ->setHelp('Use as command for parsing and recording');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $container = $this->getContainer();
        $em = $container->get('doctrine')->getManager();
        $path = $input->getArgument('path');
        $this->parseINDEX($em, $path);
        opcache_reset();
        $output->writeln("Done!");
    }

    public function parseINDEX($em, $index_filename){
        $logdir = "customProcesses/logs/parse";
        if(!file_exists($index_filename)){
            file_put_contents("$logdir/err", "No file $index_filename found\n");
            return false;
        }
        $fh = fopen($index_filename, 'r');
        if(!$fh){
            file_put_contents("$logdir/err", "Can not open $index_filename\n");
            return false;
        }
        $tot = (int)exec("wc -l '$index_filename' 2>/dev/null");
        file_put_contents("$logdir/err", "$tot lines in $index_filename\n");

        $index_repo = $em->getRepository('Core:Index');

        if (!is_dir($logdir)) {
            mkdir($logdir, 0777, true);
        }
        $logfile = "$logdir/progress";
        file_put_contents($logfile, 0);


        $first = fgets($fh);
        file_put_contents("$logdir/err", "$first\n");

        $organism_id = fgets($fh);
        file_put_contents("$logdir/err", "$organism_id\n");
        $organism_id = explode(':', $organism_id);
        file_put_contents("$logdir/err", ">>{$organism_id[1]}<<\n");
        $organism_id = $organism_id[1] == '' ? null: ( trim($organism_id[1]) == 'Drosophila melanogaster'? 7230 : (int)$organism_id[1]);
        file_put_contents("$logdir/err", "$organism_id organism_id in $index_filename\n");

        fgets($fh); fgets($fh); fgets($fh); fgets($fh); fgets($fh); # 7 top lines

        $i = 0;

        $uq = array();

        while($line= fgets($fh)){
            list($UniProtKB_ac, $iso_id, $uniprot_seq_length, $coordinate_id,
                 $provider, $from, $to, $coverage, $template, $qmean, $qmean_norm, $url) = preg_split('/\t/', $line);

            $filename = "{$from}_{$to}_{$template}_$coordinate_id";  # combined from_to_template_coordinateId

            if(!isset($uq[$filename])){
                $uq[$filename] = array('url'=>$url, 'qmean'=>$qmean, 'qmean_norm'=>$qmean_norm, 'len'=>$uniprot_seq_length);
            }else{
                $dub = $uq[$filename];
                file_put_contents("$logdir/err", "duplicate for $filename\n$qmean, $qmean_norm, $uniprot_seq_length, $url\n"
                    ."{$dub['qmean']}, {$dub['qmean_norm']}, {$dub['len']}, {$dub['url']}\n");
            }

            $index = $index_repo->find($filename);
            if( !$index ){ 
                $index = new Index();
            }
            
            $index->setFilename($filename);
            $index->setUrl(str_replace('https://swissmodel.expasy.org/repository/uniprot/', '', $url));
            $index->setOrganismId($organism_id ? $organism_id : null);
            $index->setUniProt($UniProtKB_ac);
            $index->setLen($uniprot_seq_length);
            $index->setQmean($qmean !== '' ? $qmean : null);
            $index->setQmeanNorm($qmean_norm !== '' ? $qmean_norm : null);
            $em->persist($index);

            $i++;
            if( $i%100 < 2 ){
                $em->flush();
                $em->clear();
                file_put_contents($logfile, round(100*$i/$tot));
            }
        }
        $em->flush();
        file_put_contents($logfile, 100);
        fclose($fh);
        file_put_contents("$logdir/err", "Done $index_filename\n");
        //unlink($index_filename);
    }

}
