<?php

namespace Protein\CoreBundle\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Output\OutputInterface;

use Protein\CoreBundle\Entity\Protein;
use Protein\CoreBundle\Entity\Species;

class CreateCSVCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('app:csv')
            ->addArgument('search_id', InputArgument::REQUIRED, 'Search query id in the database')
            ->setDescription('Command to create CSV file by search parameters')
            ->setHelp('Use as command to create CSV file by search parameters');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $container = $this->getContainer();
        $api_fn = $container->get('api_functions');
        $em = $container->get('doctrine')->getManager();

        $search_id = $input->getArgument('search_id');
        $this->toCSV($em, $output, $api_fn, $search_id);
        opcache_reset();
        $output->writeln("Done! $search_id");
    }

    public function toCSV($em, $output, $api_fn, $search_id){

        $search_obj = $em->getRepository('Core:Search')->find($search_id);
        if(!$search_obj){
            $output->writeln("Err: No search id  $search_id found");
            return;
        }
        $search = $search_obj->serializeArray();

        $successes = array();
        $errors = array();
        $warnings = array();

        if($search['onEntity'] == 'Protein'){
            list($schema, $search, $search_arr, $qb) = $api_fn->proteinSearch($search['search'], $successes, $errors, $warnings);
        }elseif($search['onEntity'] == 'Index'){
            list($schema, $search, $search_arr, $qb) = $api_fn->indexSearch($search['search'], $successes, $errors, $warnings);
        }else{
            $output->writeln("Err: Unsupported entity {$search['onEntity']}");
            return;
        }
        $result = $qb->getQuery()->iterate();

        $keys = array();
        $ln = 0;
        $fp = fopen("saved_searches/$search_id.csv", 'w');
        foreach($result as $row){
            $item = $row[0]->serializeArray();
            if( count($keys) == 0 ){
                $keys = array_keys($item);
                fputcsv($fp, $keys);
            }
            $vals = array();
            foreach($keys as $key){ $vals[] = $item[$key]; }
            fputcsv($fp, $vals);
            $ln++;
        }
        fclose($fp);

        $search_obj->setFilename($search_id);
        $search_obj->setCount($ln);
        $em->persist($search_obj);
        $em->flush();
/*
        $qb = $spec_repo->createQueryBuilder("ind");
        $qb->select("ind.organism_id, ind.UniProt, s.id")->distinct()
             ->innerJoin('Core:Protein', 'p', 'WITH','p.id = ind.UniProt')
             ->innerJoin('Core:Species', 's', 'WITH','p.species = s.id');
        $res = $qb->getQuery()->getArrayResult();

        foreach( $res as $r ){
            #$output->writeln("Done!");
            var_dump( $r );
        }
*/
    }


    public function groupSpeciesRecords($em, $output){
        $spec_repo = $em->getRepository('Core:Species');
        $specs = $spec_repo->findAll();
        $abbrs = array();
        foreach( $specs as $spec ){
            $abbr = trim($spec->getAbbr());
            $abbr_max = count($spec->getProteins());
            if( !isset($abbrs[$abbr]) ){
                $abbrs[$abbr] = array( 
                    'max'=>$abbr_max, 
                    'spec_id'=>$spec->getId(),
                    'spec'=>$spec,
                    'all'=>array( $spec ),
                ); 
            }else{
                $abbrs[$abbr]['all'][] = $spec;
            }
            if( $abbr_max > $abbrs[$abbr]['max'] ){
                $abbrs[$abbr]['spec_id'] = $spec->getId();
                $abbrs[$abbr]['spec'] = $spec;
                $abbrs[$abbr]['max'] = $abbr_max;
            }
        }
        $specs_to_remove = array();
        foreach( $abbrs as $key=>$abbr ){
            var_dump( $key, count($abbr['all']) );
            foreach( $abbr['all'] as $spec ){
                if( $spec->getAbbr() != $key ){
                    $spec->setAbbr($key);
                    $em->persist($spec);
                }
                if( $spec->getId() != $abbr['spec_id'] ){
                    foreach( $spec->getProteins() as $prot ){
                        $prot->setSpecies($abbr['spec']);
                        $em->persist($prot);
                    }
                    $specs_to_remove[] = $spec;
                }
            }
            $em->flush();
        }
        foreach( $specs_to_remove as $spec ){
            $em->remove($spec);
        }
        $em->flush();
    }

}

