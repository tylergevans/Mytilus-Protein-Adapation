<?php

namespace Protein\CoreBundle\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Output\OutputInterface;

use Protein\CoreBundle\Entity\Protein;
use Protein\CoreBundle\Entity\Species;

# from public folder:
# php ../bin/console app:unzip-pdb 5c3ac78da014b 'uploads/whole_from_chunks/D.busckii.7z' 'D.busckii.7z'

class UnzipPdbCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('app:unzip-pdb')
            ->addArgument('page', InputArgument::REQUIRED, 'Page slug')
            ->addArgument('path', InputArgument::REQUIRED, 'The path to file.')
            ->addArgument('filename', InputArgument::REQUIRED, 'The file name.')
            ->setDescription('Command to unzip and register folder of  .pdb files')
            ->setHelp('Use as command for unzipping .zip or .7z folder of .pdb files');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $container = $this->getContainer();
        $em = $container->get('doctrine')->getManager();
        $slug = $input->getArgument('page');
        $path = $input->getArgument('path');
        $filename = $input->getArgument('filename');
        $api_fn = $container->get('api_functions');
        $this->unzip($em, $output, $api_fn, $path, $filename, $slug);
        opcache_reset();
        $output->writeln("Done!");
    }

    public function unzip($em, $output, $api_fn, $path, $filename, $slug){
        $logdir = "customProcesses/logs/unzip-pdb/$slug";
        if (!is_dir($logdir)) {
            mkdir($logdir, 0777, true);
        }
        $logfile = "$logdir/progress";
        file_put_contents($logfile, 0);

        $start_zip = date("Y-m-d H:i:s");

        $page_repo = $em->getRepository('Core:Page');
        if($slug == '' or  !$page=$page_repo->find($slug)){
            $output->writeln("Page not found");
            return;
        }

        $info = pathinfo($filename);
        $extension = isset($info['extension'])? '.'.strtolower($info['extension']) : '';
        $output->writeln("$path >> '$extension'");

        if( $extension === '.zip' ){
            $this->unzipZip($output, $path);
        }elseif( $extension === '.7z' ){
            $this->unzip7z($output, $path);
        }else{
            $output->writeln("Unsupported extension $extension");
            return;
        }

        file_put_contents($logfile, 20);

        if(!file_exists("$path.extracted")){
            $output->writeln("Failed to unzip, no folder $filename");
            file_put_contents($logfile, 0);
            return;
        }

        unlink($path);

        $space_left = disk_free_space('/dev/xvda1');
        if($space_left == 0){
            $output->writeln("No space on disk was left after unzipping, deleting");
            $api_fn->rrmdir("$path.extracted");
            file_put_contents($logfile, 0);
            return;
        }
        $files = scandir("$path.extracted");

        $res = $api_fn->collectPDBzip($page, "$path.extracted", $logfile, $stats);

        $output->writeln("------------------------ files in total: {$stats['total']}");
        $output->writeln("Low: {$stats['low']}");
        $output->writeln("Record not found: {$stats['not_found']}");
        $output->writeln("------------------------ unique proteins: {$stats['unique_proteins']}");
        $output->writeln("Lost files: {$stats['Lost']}");
        $output->writeln("Not moved: {$stats['not_moved']}");
        $output->writeln("Low db: {$stats['low_db']}");

        $output->writeln("Start unzip: $start_zip");
        $output->writeln("Start register proteins: {$stats['start']}");
        $output->writeln("Start register: {$stats['start_files']}");
        $output->writeln("Finish: {$stats['stop']}");

        $api_fn->rrmdir("$path.extracted");

        //file_put_contents($logfile, 100);
    }


    public function unzipZip($output, $path){
        $zip = new \ZipArchive;
        $res = $zip->open($path);

        if ($res !== true) {
            $output->writeln("Can not even open zip file! $path");
        }

        $zip->extractTo("$path.extracted");
        $zip->close();
    }


    public function unzip7z($output, $path){
        $response = exec("7z x -o'$path.extracted' '$path'", $command_output);
        if($response){
            $output->writeln("7z $path response: $response");
        }elseif($command_output){
            $output->writeln("7z $path output" . implode("\n", $command_output));
        }
    }
}


