<?php

namespace Protein\CoreBundle\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Output\OutputInterface;

use Protein\CoreBundle\Entity\Protein;
use Protein\CoreBundle\Entity\Species;

# from public folder:
# php ../bin/console app:unzip-pdb 5c3ac78da014b 'uploads/whole_from_chunks/D.busckii.7z' 'D.busckii.7z'

class DropUploadRecordsCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('app:drop-upload-records')
            // ->addArgument('filename', InputArgument::REQUIRED, 'The file name.')
            ->setDescription('Command to delete upload records from the table')
            ->setHelp('Use as command for cleaning Upload table');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $container = $this->getContainer();
        $em = $container->get('doctrine')->getManager();
        //$filename = $input->getArgument('filename');
        $api_fn = $container->get('api_functions');
        $this->dropAllRecords($em, $output, $api_fn);
        opcache_reset();
        $output->writeln("Done!");
    }

    public function dropAllRecords($em, $output, $api_fn){
        $em->getRepository('Core:Upload')
                 ->createQueryBuilder("ent")
                 ->delete()
                 ->getQuery()
                 ->execute();
        //file_put_contents($logfile, 100);
    }


}


