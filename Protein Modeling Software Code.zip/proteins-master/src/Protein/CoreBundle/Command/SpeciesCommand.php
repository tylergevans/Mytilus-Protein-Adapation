<?php

namespace Protein\CoreBundle\Command;

use Symfony\Component\Console\Command\Command;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Output\OutputInterface;

use Protein\CoreBundle\Entity\Protein;
use Protein\CoreBundle\Entity\Species;

class SpeciesCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('app:species')
            ->setDescription('Command to link Index to Species by organism id')
            ->setHelp('Use as command to make link pdbs to Species');
            #->setDescription('Command to fix non unique records in species')
            #->setHelp('Use as command to make all species records unique');
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $container = $this->getContainer();
        $em = $container->get('doctrine')->getManager();
        # $this->groupSpeciesRecords($em, $output);
        # $this->insertOrganismIds($em, $output);
        $this->setIndexHbondsBridges($em, $output);
        opcache_reset();
        $output->writeln("Done!");
    }

    public function insertOrganismIds($em, $output){
        $ind_repo = $em->getRepository('Core:Index');
        $spec_repo = $em->getRepository('Core:Species');

        $spc = $spec_repo->createQueryBuilder("sp")
            ->select("sp.id, sp.organism_id")
            ->getQuery()->getArrayResult();

        $org_spc = array_column($spc, "id", "organism_id");
        var_dump( $org_spc );
        foreach($org_spc as $org_id => $spc_id){
            $qrb = $ind_repo->createQueryBuilder("ind");
            $qrb->update('Core:Index', 'pdb')
                ->set('pdb.species', ':speciesId')
                ->where('pdb.organism_id = :organismId')
                ->setParameter('organismId', $org_id)
                ->setParameter('speciesId', $spc_id);
            $qrb->getQuery()->execute();
            $em->flush();
        }

        /*
        $qb = $ind_repo->createQueryBuilder("ind");
        $qb->select("ind.organism_id, s.abbr, s.id")
             ->distinct()
             ->innerJoin('Core:Protein', 'p', 'WITH','p.id = ind.UniProt')
             ->innerJoin('Core:Species', 's', 'WITH','p.species = s.id');
        $res = $qb->getQuery()->getArrayResult();

        $dist_orgs = $ind_repo->createQueryBuilder("ind")
            ->select("ind.organism_id")
             ->distinct()
            ->getQuery()->getArrayResult();

        $spc = $spec_repo->createQueryBuilder("sp")
            ->select("sp.name, sp.abbr, sp.organism_id")
             ->distinct()
            ->getQuery()->getArrayResult();
        */

           

        /*foreach( $res as $r ){
            $spec = $spec_repo->find($r['id']);
            $spec->setOrganismId($r['organism_id']);
            $em->persist($spec);
        }
        $em->flush();*/

        /*$mylist = array(195=>7217); 

        foreach($mylist as $myid=>$orgid){
            $sp = $spec_repo->find($myid);
            $sp->setOrganismId($orgid);
            $em->persist($sp);
        }*/

       /* $nsp = new Species();
        $nsp->setName("Drosophila persimilis");
        $nsp->setAbbr("DROPE");
        $nsp->setOrganismId(7234);
        $em->persist($nsp);*/

        //$rsp = $spec_repo->find(196);
        //$em->remove( $rsp );

    }


    public function setIndexHbondsBridges($em, $output){
        $ind_repo = $em->getRepository('Core:Protein');

        $qrb = $ind_repo->createQueryBuilder("prot");
        $qrb->select('Core:Index', 'pdb')
            #->set('pdb.bonds', 'prot.bonds')
            #->set('pdb.bridges', 'prot.bridges')
            ->innerJoin('Core:Protein', 'prot', 'WITH','prot.filename = pdb.filename');
        var_dump($qrb->getDQL());

        $sql = 'UPDATE swissindex as pdb INNER JOIN proteins as prot ON prot.index_record = pdb.filename SET pdb.bonds = prot.bonds, pdb.bridges = prot.bridges';
        $stmt = $em->getConnection()->prepare($sql)->execute();
    }


    public function groupSpeciesRecords($em, $output){
        $spec_repo = $em->getRepository('Core:Species');
        $specs = $spec_repo->findAll();
        $abbrs = array();
        foreach( $specs as $spec ){
            $abbr = trim($spec->getAbbr());
            $abbr_max = count($spec->getProteins());
            if( !isset($abbrs[$abbr]) ){
                $abbrs[$abbr] = array( 
                    'max'=>$abbr_max, 
                    'spec_id'=>$spec->getId(),
                    'spec'=>$spec,
                    'all'=>array( $spec ),
                ); 
            }else{
                $abbrs[$abbr]['all'][] = $spec;
            }
            if( $abbr_max > $abbrs[$abbr]['max'] ){
                $abbrs[$abbr]['spec_id'] = $spec->getId();
                $abbrs[$abbr]['spec'] = $spec;
                $abbrs[$abbr]['max'] = $abbr_max;
            }
        }
        $specs_to_remove = array();
        foreach( $abbrs as $key=>$abbr ){
            var_dump( $key, count($abbr['all']) );
            foreach( $abbr['all'] as $spec ){
                if( $spec->getAbbr() != $key ){
                    $spec->setAbbr($key);
                    $em->persist($spec);
                }
                if( $spec->getId() != $abbr['spec_id'] ){
                    foreach( $spec->getProteins() as $prot ){
                        $prot->setSpecies($abbr['spec']);
                        $em->persist($prot);
                    }
                    $specs_to_remove[] = $spec;
                }
            }
            $em->flush();
        }
        foreach( $specs_to_remove as $spec ){
            $em->remove($spec);
        }
        $em->flush();
    }

}

