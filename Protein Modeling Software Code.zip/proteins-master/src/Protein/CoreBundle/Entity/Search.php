<?php

namespace Protein\CoreBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Constraint;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;


/**
 * Search
 *
 * @ORM\Table(name="search")
 * @ORM\Entity(repositoryClass="Protein\CoreBundle\Entity\SearchRepository")
 * @ORM\MappedSuperclass
 * @ORM\HasLifecycleCallbacks
 */
class Search
{
    /**
     * @var integer
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="string", length=50, unique=false)
     */
    private $onEntity;

    /**
     * @ORM\Column(type="string", length=1250, nullable = true, unique=false)
     */
    private $search;

    /**
     * @ORM\Column(type="string", length=250, nullable = true, unique=false)
     */
    private $filename;

    /**
     * @ORM\Column(type="integer", nullable = true)
     */
    private $count;

    /**
     * @var \DateTime
     * @ORM\Column(name="createdAt", type="datetime", nullable=false)
     */
    protected $createdAt; # should not create more then 2K requests per day, results expire in 2 weeks


    /**
     * Constructor
     */
    public function __construct()
    {
    }


    public function serializeArray()
    {
        $sch = @json_decode($this->search, true);
        return array(
            'id' => $this->id,
            'onEntity' => $this->onEntity,
            'search' => ($sch ) ? $sch : array(),
            'filename' => $this->filename,
            'count' => $this->count,
        );
    }


    /**
     * Hook on pre-persist operations
     * @ORM\PrePersist()
     */
    public function prePersist()
    {
        $this->createdAt = new \DateTime;
    }


    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }


    /**
     * Set search.
     *
     * @param string $search
     *
     * @return Search
     */
    public function setSearch($search)
    {
        $this->search = $search;

        return $this;
    }

    /**
     * Get search.
     *
     * @return string
     */
    public function getSearch()
    {
        return $this->search;
    }

    /**
     * Set filename.
     *
     * @param string $filename
     *
     * @return Search
     */
    public function setFilename($filename)
    {
        $this->filename = $filename;

        return $this;
    }

    /**
     * Get filename.
     *
     * @return string
     */
    public function getFilename()
    {
        return $this->filename;
    }

    /**
     * Set count.
     *
     * @param int|null $count
     *
     * @return Search
     */
    public function setCount($count = null)
    {
        $this->count = $count;

        return $this;
    }

    /**
     * Get count.
     *
     * @return int|null
     */
    public function getCount()
    {
        return $this->count;
    }

    /**
     * Set createdAt.
     *
     * @param \DateTime $createdAt
     *
     * @return Search
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt.
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set onEntity.
     *
     * @param string $onEntity
     *
     * @return Search
     */
    public function setOnEntity($onEntity)
    {
        $this->onEntity = $onEntity;

        return $this;
    }

    /**
     * Get onEntity.
     *
     * @return string
     */
    public function getOnEntity()
    {
        return $this->onEntity;
    }
}
