<?php

namespace Protein\CoreBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Validator\Constraint;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;


/**
 * Species
 *
 * @ORM\Table(name="species")
 * @ORM\Entity(repositoryClass="Protein\CoreBundle\Entity\SpeciesRepository")
 * @ORM\MappedSuperclass
 * @ORM\HasLifecycleCallbacks
 * @UniqueEntity(fields="name", message="Name already taken")
 */
class Species
{
    /**
     * @var integer
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @ORM\Column(type="string", length=250, unique=false)
     */
    private $name;

    /**
     * @ORM\Column(type="string", length=250, unique=false)
     */
    private $abbr;

    /**
     * @ORM\Column(type="integer", nullable = true)
     */
    private $organism_id;

    /**
     * @ORM\OneToMany(targetEntity="Protein", mappedBy="species", indexBy="id")
     * @ORM\OrderBy({"id" = "DESC"})
     */
    protected $proteins;

    /**
     * @ORM\OneToMany(targetEntity="Index", mappedBy="species")
     * @ORM\OrderBy({"id" = "DESC"})
     */
    protected $pdbs;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->proteins = new \Doctrine\Common\Collections\ArrayCollection();
    }


    public function serializeArray()
    {
        return array(
            'id' => $this->id,
            'name' => $this->name,
            'abbr' => $this->abbr,
            'organism_id' => is_null($this->organism_id) ? '-' : $this->organism_id,
            'proteins'=> 0 // count($this->proteins)
        );
    }

    public function getSerializedProteins()
    {
        $proteins = array();
        foreach($this->proteins as $protein){ $proteins[] = $protein->serializeArray(); }
    return $proteins;
    }


    /**
     * Get id.
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name.
     *
     * @param string $name
     *
     * @return Species
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name.
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set abbr.
     *
     * @param string $abbr
     *
     * @return Species
     */
    public function setAbbr($abbr)
    {
        $this->abbr = $abbr;

        return $this;
    }

    /**
     * Get abbr.
     *
     * @return string
     */
    public function getAbbr()
    {
        return $this->abbr;
    }

    /**
     * Add protein.
     *
     * @param \Protein\CoreBundle\Entity\Protein $protein
     *
     * @return Species
     */
    public function addProtein(\Protein\CoreBundle\Entity\Protein $protein)
    {
        $this->proteins[] = $protein;

        return $this;
    }

    /**
     * Remove protein.
     *
     * @param \Protein\CoreBundle\Entity\Protein $protein
     *
     * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
     */
    public function removeProtein(\Protein\CoreBundle\Entity\Protein $protein)
    {
        return $this->proteins->removeElement($protein);
    }

    /**
     * Get proteins.
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getProteins()
    {
        return $this->proteins;
    }

    /**
     * Set organismId.
     *
     * @param int $organismId
     *
     * @return Species
     */
    public function setOrganismId($organismId)
    {
        $this->organism_id = $organismId;

        return $this;
    }

    /**
     * Get organismId.
     *
     * @return int
     */
    public function getOrganismId()
    {
        return $this->organism_id;
    }

    /**
     * Add pdb.
     *
     * @param \Protein\CoreBundle\Entity\Index $pdb
     *
     * @return Species
     */
    public function addPdb(\Protein\CoreBundle\Entity\Index $pdb)
    {
        $this->pdbs[] = $pdb;

        return $this;
    }

    /**
     * Remove pdb.
     *
     * @param \Protein\CoreBundle\Entity\Index $pdb
     *
     * @return boolean TRUE if this collection contained the specified element, FALSE otherwise.
     */
    public function removePdb(\Protein\CoreBundle\Entity\Index $pdb)
    {
        return $this->pdbs->removeElement($pdb);
    }

    /**
     * Get pdbs.
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPdbs()
    {
        return $this->pdbs;
    }
}
