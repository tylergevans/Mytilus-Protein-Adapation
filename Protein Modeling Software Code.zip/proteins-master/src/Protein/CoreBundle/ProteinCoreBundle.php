<?php
namespace Protein\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProteinCoreBundle extends Bundle
{
}
