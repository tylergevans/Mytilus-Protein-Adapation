<?php

namespace Protein\CoreBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\RedirectResponse;

use Protein\CoreBundle\Entity\Page;
use Protein\CoreBundle\Entity\Search;

class LandingController extends Controller
{

    const DEFAULT_PAGE_LIMIT = 100;
    const DEBUG_ON = true;
    const DEBUG_MYSQL_ON = false;

    public function log($text){
        if(!self::DEBUG_ON){ return; }
        file_put_contents('uploads/out', $text, FILE_APPEND);
    }

    public function logmysql($text){
        if(!self::DEBUG_MYSQL_ON){ return; }
        file_put_contents('uploads/mysql', $text, FILE_APPEND);
    }

    public function lines_in_file($filename){
        return (int)exec("wc -l '$filename' 2>/dev/null") -1;
    }

    # calls symfony command app:name asynchronously
    public function asyncCustomProcess($name, $action, $params_count, $params){
        ### >/dev/null 2>/dev/null    is really important for initiating async process
        exec("nohup php customProcesses/genericAsyncCommand.php $name $action $params_count $params >/dev/null 2>/dev/null &");
    }

    public function checkProcessRunning($name){
        $parsing_processes = '';
        exec( "ps -ax|grep '$name'|grep -v grep", $parsing_processes );
        return ( count($parsing_processes)> 0 );
    }

    public function processProgress($name, $pageslug){
        $progress_file = "customProcesses/logs/$name/$pageslug";
        return (file_exists($progress_file))? file_get_contents($progress_file) : 0;
    }

    public function landingAction($_subpage='', $pageslug='', Request $request){
        $this->log("landing slug: '$pageslug', subpage: $_subpage\n");

        $em = $this->getDoctrine()->getManager();

        $route_name = $request->attributes->get('_route');

        $page_repo = $em->getRepository('Core:Page');
        if($pageslug == '' or !$page = $page_repo->find($pageslug)){
            if($pageslug == 'createnewpage'){
                $page = $this->getPage();
                return $this->redirectToRoute('protein_core_page', ['pageslug'=>$page->getId()]);
            }
            return $this->render('@ProteinCore/index_no_slug.html.twig', ['pageslug'=>$pageslug]);
        }

    
        if( isset($_GET['delete']) ){
            $em->remove($page);
            $em->flush();
            return $this->render('@ProteinCore/index_no_slug.html.twig', ['pageslug'=>$pageslug]);
        }

        $subpage_ind = ($_subpage != '') ? $_subpage : 1;
        $per_page = self::DEFAULT_PAGE_LIMIT;
        list($proteins, $pagination) = $this->get('api_functions')->getEntityPagination(
            $page, 
            'Core:Protein', true, 
            $subpage_ind, 
            $per_page,
            'proteinPage');  

        list($uploads, $u_pagination) = $this->get('api_functions')->getEntityPagination(
            $page, 
            'Core:Upload', false,
            $subpage_ind, 
            $per_page,
            'uploadPage');  


        $parsing_on = $this->checkProcessRunning('app:parse-index');
        $collect_on = $this->checkProcessRunning('app:collect');
        $hbonds_on = $this->checkProcessRunning("app:hbonds $pageslug");
        $fasta_on = $this->checkProcessRunning("app:fasta $pageslug");
        $models_on = $this->checkProcessRunning("app:swiss $pageslug");
        $amino_parsing_on = $this->checkProcessRunning("app:amino $pageslug");

        $hbonds_progress = $this->processProgress("hbonds", $pageslug);
        $fasta_progress = $this->processProgress("fasta", $pageslug);
        $models_progress = $this->processProgress("swiss", $pageslug);


        $ind_repo = $em->getRepository('Core:Index');
        $query = $ind_repo->createQueryBuilder("fi")
                ->select("count(fi)");
        $this->logmysql("Landing count Query:\n". $query->getDQL() ."\n");
        $this->logmysql("Landing count Query:\n". memory_get_peak_usage() ."\n");
        $count = $query->getQuery()->getSingleScalarResult();
        $this->logmysql("Landing count Query:\n". memory_get_peak_usage() ."\n");


        $req_repo = $em->getRepository('Core:ModelRequest');
        $qr = $req_repo->createQueryBuilder("r");
        $date = new \DateTime();
        $date->modify('-24 hour');
        $requests_today_query = $qr->select('count(r.id)')
            ->andWhere('r.createdAt > :date')
            ->setParameter(':date', $date);
        $this->logmysql("Landing req today Query:\n". $requests_today_query->getDQL() ."\n");
        $this->logmysql("Landing req today Query:\n". memory_get_peak_usage() ."\n");
        $requests_today = $requests_today_query->getQuery()->getSingleScalarResult();
        $this->logmysql("Landing req today Query:\n". memory_get_peak_usage() ."\n");


        $pages_query = $page_repo->createQueryBuilder("p")
                ->select("p.id, p.createdAt");
        $this->logmysql("Landing pages Query:\n". $pages_query->getDQL() ."\n");
        $this->logmysql("Landing pages Query:\n". memory_get_peak_usage() ."\n");
        $pages = $pages_query->getQuery()->getArrayResult();
        $this->logmysql("Landing pages Query:\n". memory_get_peak_usage() ."\n");


        $amino_repo = $em->getRepository('Core:Amino');
        $hour_ago = new \DateTime();
        $hour_ago->modify('-1 hour');
        foreach( $pages as &$page ){
            $amino_rec = $amino_repo->createQueryBuilder("a")
              ->select("a.id")
              ->innerJoin('a.pages','pages')
              ->innerJoin('Core:Page', 'p', 'WITH','p.id = pages.id')
              ->where("p.id='{$page['id']}'")
              ->setMaxResults( 1 )
              ->getQuery()->getArrayResult();
            if( $page['id'] == $pageslug ){ 
                $amino_count =  count($amino_rec);
            }
            $page['amino'] = count($amino_rec);
        }

        return $this->render('@ProteinCore/index.html.twig', [
            'pageslug'=>$pageslug,
            'proteins'=> $proteins, 
            'pagination'=>json_encode(array('pagination'=>$pagination)),
            'uploads_pagination'=>json_encode(array('uploads_pagination'=>$u_pagination)),
            'uploads'=> $uploads, 
            'index_count'=> $count,
            'parsing_on'=> $parsing_on,
            'amino_index_count'=> $amino_count,
            'amino_parsing_on'=> $amino_parsing_on,
            'hbonds_on'=> $hbonds_on,
            'hbonds_progress'=>$hbonds_progress,
            'fasta_on'=>$fasta_on,
            'fasta_progress'=>$fasta_progress,
            'models_on'=>$models_on,
            'models_progress'=>$models_progress,
            'collect_on'=>$collect_on,
            'pages'=> $pages,
            'model_requests_today'=>$requests_today,
            ]);
    }


    public function indexglobalAction($_subpage='', Request $request){
        $this->log("indexglobal\n");

        $api_fn = $this->get('api_functions');

        $em = $this->getDoctrine()->getManager();

        ################ JSON search calls ################

        if( isset($_POST['list']) ){
            $col = $_POST['list'];

            $cols = $api_fn::INDEX_SEARCH_DATA;
            $ref = $cols[ $col ]['reference'];
            if($ref){
                $ref_field = $cols[ $col ]['ref_field'];
                $ent_repo = $em->getRepository("Core:$ref");
                $qb = $ent_repo->createQueryBuilder("s");
                $qb->select("s.$ref_field")
                   ->distinct();
            }else{
                $ent_repo = $em->getRepository('Core:Index');
                $qb = $ent_repo->createQueryBuilder("s");
                $qb->select("s.$col")
                   ->distinct();
            }

            $list = $qb->getQuery()->getArrayResult();
            return $this->json($list);
        }

        ## delete csv file of saved search
        if( isset($_POST['delete']) ){
            $del_srch = $em->getRepository('Core:Search')->find($_POST['delete']);
            if(!$del_srch){
                return $this->json(array('error'=>"Could not find search id {$_POST['delete']}"));
            }
            $filename = $del_srch->getFilename();
            $em->remove($del_srch);
            $em->flush();
            if( $filename and file_exists("saved_searches/$filename.csv") ){
                unlink("saved_searches/$filename.csv");
            }
            return $this->json(array('successes'=>'deleted'));
        }

        ## initiate process of creating csv file of search results
        if( isset($_POST['csv']) and isset($_POST['search'])){
            $search = new Search();
            $search->setOnEntity('Index');
            $search->setSearch(json_encode($_POST['search']));
            $em->persist($search);
            $em->flush();
            if($id = $search->getId()) {
                $this->asyncCustomProcess('csv', 'start', 1, $id);
                return $this->json(array('successes'=>'initiated'));
            }
            return $this->json(array('error'=>'Could not save search'));
        }


        ################ Page rendering ################

        $successes = array();
        $errors = array();
        $warnings = array();

        $subpage_ind = ($_subpage != '') ? $_subpage : 1;
        $per_page = self::DEFAULT_PAGE_LIMIT;
        $pagination = null;

        $search_post = isset($_POST['search']) ? $_POST['search'] : null;
        list($schema, $search, $search_arr, $qb) = $api_fn->indexSearch($search_post, $successes, $errors, $warnings);

        if ($qb) {
            list($proteins, $pagination) = $api_fn->getEntityPaginationQB(
                $qb,
                $subpage_ind,
                $per_page,
                'indexPage');
        }

        if(!$pagination){
            list($proteins, $pagination) = $this->get('api_functions')->getEntityPagination(
                null,
                'Core:Index', true,
                $subpage_ind,
                $per_page,
                'indexPage');
        }

        $files = array();
        $searches_limit = 10;
        $searches_offset = 0;
        $search_repo = $em->getRepository('Core:Search');
        $searches = $search_repo->findBy(
            array('onEntity'=>'Index'),
            array('createdAt'=>'ASC'),
            $searches_limit,
            $searches_offset);
        foreach( $searches as $s ){ $files[] = $s->serializeArray(); }

        return $this->render('@ProteinCore/indexglobal.html.twig', [
            'proteins'=>$proteins,
            'pagination'=>json_encode(array('pagination'=>$pagination)),
            'searchdata'=>json_encode($schema),
            'searchquery'=>json_encode($search_arr),
            'searchfiles'=>json_encode($files),
        ]);
    }


    public function indexglobalsearchAction($_subpage='', Request $request){
        $this->log("indexglobal search\n");

        $em = $this->getDoctrine()->getManager();

        $subpage_ind = ($_subpage != '') ? $_subpage : 1;
        $per_page = self::DEFAULT_PAGE_LIMIT;

        list($proteins, $pagination) = $this->get('api_functions')->getEntityPagination(
            null,
            'Core:Index', true,
            $subpage_ind,
            $per_page,
            'indexPage');

        return $this->render('@ProteinCore/indexsearch.html.twig', [
            'proteins'=>$proteins,
            'pagination'=>json_encode(array('pagination'=>$pagination)),
        ]);
    }


    public function proteinAction($_subpage='', Request $request){
        $this->log("protein\n");

        $api_fn = $this->get('api_functions');

        $em = $this->getDoctrine()->getManager();

        if( isset($_POST['list']) ){
            $col = $_POST['list'];

            $cols = $api_fn::PROTEIN_SEARCH_DATA;
            $ref = $cols[ $col ]['reference'];
            if($ref){
                $ref_field = $cols[ $col ]['ref_field'];
                $ent_repo = $em->getRepository("Core:$ref");
                $qb = $ent_repo->createQueryBuilder("s");
                $qb->select("s.$ref_field")
                   ->distinct();
            }else{
                $ent_repo = $em->getRepository('Core:Protein');
                $qb = $ent_repo->createQueryBuilder("s");
                $qb->select("s." . $_POST['list'])
                   ->distinct();
            }
            $list = $qb->getQuery()->getArrayResult();
            return $this->json($list);
        }

        if( isset($_POST['delete']) ){
            $del_srch = $em->getRepository('Core:Search')->find($_POST['delete']);
            if(!$del_srch){
                return $this->json(array('error'=>"Could not find search id {$_POST['delete']}"));
            }
            $filename = $del_srch->getFilename();
            $em->remove($del_srch);
            $em->flush();
            if( $filename and file_exists("saved_searches/$filename.csv") ){
                unlink("saved_searches/$filename.csv");
            }
            return $this->json(array('successes'=>'deleted'));
        }

        if( isset($_POST['csv']) and isset($_POST['search'])){
            $search = new Search();
            $search->setOnEntity('Protein');
            $search->setSearch(json_encode($_POST['search']));
            $em->persist($search);
            $em->flush();
            if($id = $search->getId()) {
                $this->asyncCustomProcess('csv', 'start', 1, $id);
                return $this->json(array('successes'=>'initiated'));
            }
            return $this->json(array('error'=>'Could not save search'));
        }

        $successes = array();
        $errors = array();
        $warnings = array();

        $subpage_ind = ($_subpage != '') ? $_subpage : 1;
        $per_page = self::DEFAULT_PAGE_LIMIT;
        $pagination = null;

        $search_post = isset($_POST['search']) ? $_POST['search'] : null;
        list($schema, $search, $search_arr, $qb) = $api_fn->proteinSearch($search_post, $successes, $errors, $warnings);

        if ($qb) {
            list($proteins, $pagination) = $api_fn->getEntityPaginationQB(
                $qb,
                $subpage_ind,
                $per_page,
                'indexPage');
        }

        if(!$pagination){
            list($proteins, $pagination) = $this->get('api_functions')->getEntityPagination(
                null,
                'Core:Protein', true,
                $subpage_ind,
                $per_page,
                'indexPage');
        }

        $files = array();
        $searches_limit = 10;
        $searches_offset = 0;
        $search_repo = $em->getRepository('Core:Search');
        $searches = $search_repo->findBy(
            array('onEntity'=>'Protein'), 
            array('createdAt'=>'ASC'), 
            $searches_limit, 
            $searches_offset);
        foreach( $searches as $s ){ $files[] = $s->serializeArray(); }        

        return $this->render('@ProteinCore/protein.html.twig', [
            'proteins'=>$proteins,
            'pagination'=>json_encode(array('pagination'=>$pagination)),
            'searchdata'=>json_encode($schema), 
            'searchquery'=>json_encode($search_arr), 
            'searchfiles'=>json_encode($files),
        ]);
    }



    public function requestsAction($_subpage='', Request $request){
        $this->log("requests action\n");

        $em = $this->getDoctrine()->getManager();

        $subpage_ind = ($_subpage != '') ? $_subpage : 1;
        $per_page = self::DEFAULT_PAGE_LIMIT;

        list($proteins, $pagination) = $this->get('api_functions')->getEntityPagination(
            null,
            'Core:ModelRequest', true,
            $subpage_ind,
            $per_page,
            'requestsPage');

        return $this->render('@ProteinCore/requests.html.twig', [
            'proteins'=>$proteins,
            'pagination'=>json_encode(array('pagination'=>$pagination)),
        ]);
    }


    public function speciesAction($_subpage='', Request $request){
        $api_fn = $this->get('api_functions');

        $this->log("species\n");

        $em = $this->getDoctrine()->getManager();

        if( isset($_POST['list']) ){
            $ent_repo = $em->getRepository('Core:Species');
            $qb = $ent_repo->createQueryBuilder("s");
            $qb->select("s." . $_POST['list'])
               ->distinct();
            $list = $qb->getQuery()->getArrayResult();
            return $this->json($list);
        }

        $successes = array();
        $errors = array();
        $warnings = array();

        $subpage_ind = ($_subpage != '') ? $_subpage : 1;
        $per_page = self::DEFAULT_PAGE_LIMIT;

        list($schema, $search, $search_arr, $species, $pagination) = $api_fn->speciesSearch(
            $subpage_ind, 
            $per_page, 
            $successes, $errors, $warnings);        

        foreach($species as &$organism){
            $organism['proteins'] = $em->getRepository('Core:Index')
                ->createQueryBuilder("ind")
                ->select('count(ind.UniProt)')
                ->distinct()
                ->where('ind.organism_id = :orgID')
                ->setParameter(':orgID', $organism["organism_id"])
                ->getQuery()->getSingleScalarResult();
            if( $organism['proteins'] == 0 ){
                $organism['proteins'] = $em->getRepository('Core:Protein')
                    ->createQueryBuilder("p")
                    ->select('count(p.id)')
                    ->innerJoin('Core:Species', 's', 'WITH','s.id = p.species')
                    ->where('s.id = :spec')
                    ->setParameter(':spec', $organism['id'])
                    ->getQuery()->getSingleScalarResult();
            }
        }


        return $this->render('@ProteinCore/species.html.twig', [
            'proteins'=>$species,
            'pagination'=>json_encode(array('pagination'=>$pagination)),
            'searchdata'=>json_encode($schema), 
            'searchquery'=>json_encode($search_arr), 
        ]);
    }


    public function aminotableAction($_subpage='', $pageslug='', Request $request){
        $this->log("amino table $pageslug\n");

        $em = $this->getDoctrine()->getManager();

        $page_repo = $em->getRepository('Core:Page');
        if($pageslug == '' or !$page = $page_repo->find($pageslug)){
            return $this->redirect($this->generateUrl('protein_core_page', ['pageslug'=>$pageslug]));
        }

        $subpage_ind = ($_subpage != '') ? $_subpage : 1;
        $per_page = self::DEFAULT_PAGE_LIMIT;

        list($proteins, $pagination) = $this->get('api_functions')->getEntityPagination(
            $page, 
            'Core:Amino', true,
            $subpage_ind, 
            $per_page,
            'aminoPage');  

        return $this->render('@ProteinCore/amino.html.twig', [
            'proteins'=>$proteins,
            'pagination'=>json_encode(array('pagination'=>$pagination)),
            'pageslug'=>$pageslug,
        ]);
    }

    public function aminoAction(Request $request){
        $this->log("amino file\n");

        $page = $this->getPage();
        $slug = $page->getId();

        $successes = array();
        $errors = array();
        $warnings = array();

        if ( $file_upload_res = $this->get('api_functions')->fileDrop('AMINO', $errors) ){
            if( $file_upload_res['final'] ){
                $this->asyncCustomProcess('amino', 'start', 2, "$slug '{$file_upload_res['path']}'");
            }
            return $this->json( $file_upload_res );
        }
        $errors[] = 'fileDrop returned false';
        return $this->json(array( 'errors'=>$errors, 'warnings'=>$warnings ));
    }
 
    public function indexAction(Request $request){
        $this->log("index file\n");

        $successes = array();
        $errors = array();
        $warnings = array();

        if ( $file_upload_res = $this->get('api_functions')->fileDrop('INDEX', $errors) ){
            if( $file_upload_res['final'] ){
                $this->asyncCustomProcess('parse', 'start', 1, "'{$file_upload_res['path']}'");
            }
            return $this->json( $file_upload_res );
        }
        $errors[] = 'fileDrop returned false';
        return $this->json(array( 'errors'=>$errors, 'warnings'=>$warnings ));
    }


    public function swissAction(Request $request){
        $this->log("swiss command\n");

        $page = $this->getPage();

        if(isset($_POST['start'])){
            $this->asyncCustomProcess('swiss', 'start', 1, $page->getId());
            return $this->json(array('successes'=>'Process initiated', 'page'=>$page->getId()));
        }
        if(isset($_POST['stop'])){
            $this->asyncCustomProcess('swiss', 'stop', 1, $page->getId());
            return $this->json(array('successes'=>'Process terminate', 'page'=>$page->getId()));
        }
        return $this->json(array('No start/stop action provided'));
    }

 
    public function calculateAction(Request $request){
        $this->log("calculate command\n");

        $page = $this->getPage();

        if(isset($_POST['start'])){
            $this->asyncCustomProcess('hbonds', 'start', 1, $page->getId());
            return $this->json(array('successes'=>'Process initiated', 'page'=>$page->getId()));
        }
        if(isset($_POST['stop'])){
            $this->asyncCustomProcess('hbonds', 'stop', 1, $page->getId());
            return $this->json(array('successes'=>'Process terminate', 'page'=>$page->getId()));
        }
        return $this->json(array('No start/stop action provided'));
    }

    public function fastaAction(Request $request){
        $this->log("fasta file\n");

        $successes = array();
        $errors = array();
        $warnings = array();

        if ( $file_upload_res = $this->get('api_functions')->fileDrop('FASTA', $errors) ){

            if( !$file_upload_res['final'] ){ 
                return $this->json($file_upload_res);
            }

            $page = $this->getPage();
            $slug = $page->getId();
            $path = $file_upload_res['path'];

            $tot = $this->lines_in_file($path);
            if($tot < 3000){
                $this->get('api_functions')->parseFASTA($page, $path, $successes, $errors, $warnings);
            }else{
                $this->asyncCustomProcess('fasta', 'start', 2, "$slug '$path'");
            }

            return $this->json(array(
                'reload'=>($tot < 3000), 
                'page'=>$slug, 
                'successes'=>$successes, 
                'errors'=>$errors, 
                'warnings'=>$warnings ));
        }

        $errors[] = 'fileDrop returned false';
        return $this->json(array( 'errors'=>$errors, 'warnings'=>$warnings ));
    }


    public function pdbfileAction(Request $request){
        $this->log("pdb file\n");

        $successes = array();
        $errors = array();
        $warnings = array();

        if ( $file_upload_res = $this->get('api_functions')->fileDrop('PDB', $errors) ){
        
            if( !isset($file_upload_res['path']) or !$file_upload_res['final'] ){ 
                return $this->json($file_upload_res);
            }

            $page = $this->getPage();
            $slug = $page->getId();
            $path = $file_upload_res['path'];
            $filename = $file_upload_res['name'];

            $info = pathinfo($filename);
            $extension = isset($info['extension'])? '.'.strtolower($info['extension']) : '';

            if( $extension != '.zip' and $extension != '.7z' ){
                $this->get('api_functions')->collectPDB($page, $path, $filename, $successes, $errors, $warnings);
            }else{
                $this->asyncCustomProcess('unzip-pdb', 'start', 3, "$slug '$path' '$filename'");
            }

            return $this->json(array(
                'result' => $file_upload_res,
                'page'=>$slug, 
                'successes'=>$successes, 
                'errors'=>$errors, 
                'warnings'=>$warnings ));

        }
        $errors[] = 'fileDrop returned false';
        return $this->json(array( 'errors'=>$errors, 'warnings'=>$warnings ));
    }


    public function getPage(){
            $em = $this->getDoctrine()->getManager();
            $page_repo = $em->getRepository('Core:Page');

            if(isset($_POST['pageslug']) and  $_POST['pageslug'] != '' and $page=$page_repo->find($_POST['pageslug'])){
                $this->log("page slug {$_POST['pageslug']} is valid\n");
            }else{
                $requested_page = !isset($_POST['pageslug']) ? 'slug not set' : $_POST['pageslug'];
                $page = new Page();
                $page->setId(uniqid());
                $em->persist($page);
                $em->flush();
                $this->log("NEW PAGE CREATED {$page->getId()} (initially requested: $requested_page)\n" . $this->getReport() . "\n");
            }
    return $page;
    }

    public function getReport(){

        $ts = time();
        /////////////// detecting ip ////////////////////////////
        $client  = isset($_SERVER['HTTP_CLIENT_IP']) ? $_SERVER['HTTP_CLIENT_IP'] : 'no ip';
        $forward = isset($_SERVER['HTTP_X_FORWARDED_FOR']) ? $_SERVER['HTTP_X_FORWARDED_FOR'] : 'no forward';
        $remote  = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'no remote addr';

        if(filter_var(     $client,  FILTER_VALIDATE_IP)){
            $ip = $client;
        }elseif(filter_var($forward, FILTER_VALIDATE_IP)){
            $ip = $forward;
        }elseif(filter_var($remote,  FILTER_VALIDATE_IP)){
            $ip = $remote;
        }else{
            $ip = 'no_ip';
        }
        /////////////// detecting pageURL ////////////////////////////
        $pageURL = ( isset($_SERVER["HTTPS"]) and $_SERVER["HTTPS"] != "off" )? "https://" : "http://";
        $port = ( !isset($_SERVER["SERVER_PORT"] ) )? '' : ':'.$_SERVER["SERVER_PORT"];
        if ( ($pageURL == "https://" and $port == ":443" ) or
             ($pageURL == "http://" and $port == ":80" ) ){
                $port = '';
        }
        $pageURL .= $_SERVER["SERVER_NAME"].$port.$_SERVER["REQUEST_URI"];
        ////////////// detecting referer /////////////////////////////
        $referer = ( isset($_SERVER['HTTP_REFERER']) and $pageURL != $_SERVER['HTTP_REFERER'] )?
                        htmlspecialchars( $_SERVER['HTTP_REFERER'] ) : 'no_referer';
        ////////////// detecting client agent ////////////////////////
        $agent = ( isset($_SERVER["HTTP_USER_AGENT"]))? $_SERVER["HTTP_USER_AGENT"]:'unknown';

    return implode( ', ', array( $ip, $ts, $pageURL, $referer, $agent));
    }

}
