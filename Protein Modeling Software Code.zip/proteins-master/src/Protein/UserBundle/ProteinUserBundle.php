<?php
namespace Protein\UserBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProteinUserBundle extends Bundle
{
}
