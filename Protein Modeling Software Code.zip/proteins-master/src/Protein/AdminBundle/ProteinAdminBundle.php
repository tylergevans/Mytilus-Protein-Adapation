<?php
namespace Protein\AdminBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ProteinAdminBundle extends Bundle
{
}
