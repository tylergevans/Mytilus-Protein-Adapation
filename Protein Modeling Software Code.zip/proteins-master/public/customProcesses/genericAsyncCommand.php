<?php

$pid = getmypid();
if (!is_dir("customProcesses/logs")) {
    mkdir("customProcesses/logs", 0755, true);
}

if($argc < 4){
    if (!is_dir("customProcesses/logs/generic")) {
        mkdir("customProcesses/logs/generic", 0755, true);
    }
    file_put_contents("customProcesses/logs/generic/err", "$pid Not enough arguments for $name\n", FILE_APPEND);
    exit(1);
}

$name = $argv[1];
$action = $argv[2];
$params_count = $argv[3];
$params_line = implode(' ', array_slice($argv, 4));

$log_dir = "customProcesses/logs/$name";
if (!is_dir($log_dir)) {
    mkdir($log_dir, 0755, true);
}

cli_set_process_title( "{$name}_command_wrapper" );

if($argc < 4 + $params_count){
    file_put_contents("$log_dir/err", "$pid Not enough arguments\n", FILE_APPEND);
    exit(1);
}


$same_processes = array();
exec( "ps -ax|grep 'app:$name $params_line'|grep -v grep", $same_processes );

if( count( $same_processes ) > 0 and $action=='start'){
    file_put_contents("$log_dir/err", "$pid Same process detected, try again later\n", FILE_APPEND);
    exit(1);
}

if( count( $same_processes ) === 0  and $action=='stop' ){
    file_put_contents("$log_dir/err", "No process to stop\n", FILE_APPEND);
    exit(1);
}

if( count( $same_processes ) > 0 and $action=='stop'){
    $running_pid = preg_replace("/\s+.*/", "", trim($same_processes[0]));
    exec("kill -9 $running_pid");
    // repeat check
    $same_processes = array();
    exec( "ps -ax|grep 'app:$name $params_line'|grep -v grep", $same_processes );
    // report
    if( count($same_processes)>0 ){
        file_put_contents("$log_dir/err", "Failed to terminate the process $running_pid\n", FILE_APPEND);
    }else{
        file_put_contents("$log_dir/err", "Process terminated\n", FILE_APPEND);
    }
    exit(1);
}

# Actual initiating of the command:
exec("nohup php ../bin/console app:$name $params_line --no-debug > $log_dir/out 2>$log_dir/err &");
# This generic wrapper around command  will end as soon as nohup starts

