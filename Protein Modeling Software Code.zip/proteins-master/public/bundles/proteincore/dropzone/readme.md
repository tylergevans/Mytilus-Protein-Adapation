# Warning!

You shouldn't pull these files from the github master branch directly!

They might be outdated or not working at all since I normally only push them
when I create a version release.

To be sure to get a proper release, please go to the
[dropzone releases section on github](https://github.com/enyo/dropzone/releases/latest).

