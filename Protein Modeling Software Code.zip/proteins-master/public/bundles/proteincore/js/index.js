
Dropzone.autoDiscover = false;
$('.mydropzone').addClass('dropzone');

var webSocket = window.WebSocket || window.MozWebSocket;

var Pagination = function(paClass, config){
    this.init(paClass, config);
};

Pagination.prototype = {

    paNode: null,

    init: function(paClass, st){
        this.paNode = $(paClass);
        console.log(paClass, this.paNode, st );
        if('undefined' == typeof(st.pagination) || this.paNode.length == 0){ return; }
        console.log(paClass, '%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%' );
        this.generate(st.pagination);
    },
    bind: function(){
    },
    activatePage: function(p){
        var prev = this.paNode.find('.page-item-previous'), 
            current = this.paNode.find('.page-link[data-id=' + p.current + ']').closest('.page-item'),
            next = this.paNode.find('.page-item-next');

        if('undefined' == typeof(p.previous)){
            prev.addClass('disabled');
            prev.html('<span class="page-link">Previous</span>');
        }else{
            prev.removeClass('disabled');
            prev.html('<a class="page-link" data-id="' + p.previous + '" href="' + p.previous + '">Previous</a>');
        }

        
        if( current.length > 0 ){
            current.addClass('active');
            current.html('<span class="page-link">' + p.current + '</span>');
        }

        if('undefined' == typeof(p.next)){
            next.addClass('disabled');
            next.html('<span class="page-link">Next</span>');
        }else{
            next.removeClass('disabled');
            next.html('<a class="page-link" data-id="' + p.next + '" href="' + p.next + '">Next</a>');
        }
    },
    generate: function(p){
        console.log(this.paNode, p, '********************');
        this.paNode.append('<li class="page-item"><a class="page-link" href="1">First (1)</a></li>');
        this.paNode.append('<li class="page-item page-item-previous"></li>');
        var that = this;
        $.each(p.pagesInRange, function(i, pg){
            that.paNode.append('<li class="page-item"><a class="page-link range-page" data-id="' 
                + pg + '" href="' + pg + '">' + pg + '</a></li>');
        });
        this.paNode.append('<li class="page-item page-item-next"></li>');
        this.paNode.append('<li class="page-item"><a class="page-link" href="' + p.last + '">Last (' + p.last + ')</a></li>');
        this.paNode.parent().append( '<span class="navbar-text ml-3">' + p.numItemsPerPage + ' per page, ' 
            + p.currentItemCount + ' on page, total ' + p.totalCount + '</span>');
        if(p.totalCount == 0){ this.paNode.parent().addClass('hidden'); }
        this.activatePage( p );
    }
}

var Search = {
    init: function(){
        if( $('.search-form').length == 0 ){ return; }

        Search.data = JSON.parse(window.__SEARCH__);
        Search.query = JSON.parse(window.__SEARCH_QUERY__);
        Search.files = JSON.parse(window.__SEARCH_FILES__);
        Search.form = $('form.search-form');
        console.log('Query', Search.query);
        if( typeof Search.query != 'underfined' && Search.query && Search.query.length > 0 ){
            for ( var i = 0; i < Search.query.length; i++ ){
                Search.addLine(Search.query[i]);
            }
        } else {
            Search.addLine(null);
        }
    },
    bind: function(){
        // show search block with 1 line on click
    },
    bindLines: function(){
        // ddn selection
        $('.searchFormLine .dropdown-item').off('click').on('click', function(e){
            e.preventDefault();
            var val = $(this).text();
            var btn_gr = $(this).closest('.btn-group')
            btn_gr.find('.dropdown-toggle').html( val );
            btn_gr.find('input').val( val );
            if( $(this).closest('.btn-group').hasClass('columnDDN') ){

                var line = $(this).closest('.searchFormLine');
                Search.setInputBlock(line);
            }
        });
        // click remove line
        $('.searchFormLine .dropdown-item.remove-search-line').off('click').on('click', function(e){
            e.preventDefault();
            $(this).closest('.searchFormLine').remove();
        });
        // remove BoolBlock from first line // set first line Input length
        var firstLine = $('.searchFormLine:first-child');
        firstLine.find('.searchBoolBlock').remove();
        firstLine.find('.searchInputBlock').removeClass('col-6').addClass('col-7');
        // click add line or reset search
        $('.addSearchLine').off('click').on('click', function(e){
            e.preventDefault();
            Search.addLine();
        });
        $('.resetSearch').off('click').on('click', function(e){
            e.preventDefault();
            Search.form.empty();
            Search.addLine();
        });

        $('.inputTypeDDN').off('click').on('click', function(e){
            e.preventDefault();
            var line = $(this).closest('.searchFormLine');
            Search.inputAsDDN(line, '');
        });
        $('.inputTypeInput').off('click').on('click', function(e){
            e.preventDefault();
            var line = $(this).closest('.searchFormLine');
            Search.inputAsInput(line, '');
        });
        $('.inputTypeRange').off('click').on('click', function(e){
            e.preventDefault();
            var line = $(this).closest('.searchFormLine');
            Search.inputAsRange(line);
        });

        $('.submitSearchBlock button').off('click').on('click', function(e){
            e.preventDefault();
            Search.submitSearch();
        });

        $('.requestCSV button').off('click').on('click', function(e){
            e.preventDefault();
            Search.requestCSV();
        });

        $('a.deleteFile').off('click').on('click', function(e){
            e.preventDefault();
            Search.deleteFile( $(this) );
        });

        $('.searchInputBlock input').off('keypress').on('keypress', function(e){
            var keycode = (e.keyCode ? e.keyCode : e.which);
            if(keycode == '13'){
                Search.submitSearch();
            }
        });
    },
    deleteFile: function(obj){
        console.log(obj);
        $.post('', "delete=" + obj.data('id'))
         .done(function(reply){ 
            if( typeof reply.successes != 'undefined' ){
                obj.closest('small').remove();
                flashCard.add('success', 'deleted');
            }else if( typeof reply.errors != 'undefined' ){
                flashCard.add('error', reply.errors);
            }
            console.log(reply); 
         })
         .fail(function(a,b,c){ console.log(a,b,c); });
    },
    submitSearch: function(){
        $('.searchFormLine').each(function(i,line){
            Search.lineParamsToForm(i, line);
        });
        Search.form.submit(); 
    },
    requestCSV: function(){
        var params = ['csv=1'];
        $('.searchFormLine').each(function(i,line){
            params.push( Search.lineParamsToString(i, line) );
        });
        console.log(params.join('&'));
        $.post('', params.join('&'))
         .done(function(reply){ 
            if( typeof reply.successes != 'undefined' ){
                flashCard.add('success', 'Initiated, refresh the page');
            }else if( typeof reply.error != 'undefined' ){
                flashCard.add('errors', reply.errors);
            }
            console.log(reply); 
         })
         .fail(function(a,b,c){ console.log(a,b,c); });
    },
    validRange: function(line, vals){
        return vals;
    },
    getLineData: function(line){
        var condition = ( $(".searchBoolBlock").length > 0 ) ? $(line).find(".searchBoolBlock button").text().trim() : 'And';
        var col = $(line).find('.searchColumnBlock button').text().trim();

        var inps = $(line).find('.searchInputBlock input');
        var vals = [];
        inps.each(function(i, inp){ 
            vals.push({kind: $(inp).data('kind'), val: $(inp).val()}); 
        });
        if( vals.length == 2 ){ vals = Search.validRange(line, vals); }
    return {condition: condition, col: col, vals: vals};
    },
    lineParamsToForm: function(i, line){
        var data = Search.getLineData(line);
        var cs = 'search[' + i + '][';
        Search.form.append('<input type="hidden" name="' + cs +  'col]' + '" value="' +  data.col + '" />');
        Search.form.append('<input type="hidden" name="' + cs +  'bool]' + '" value="' + data.condition + '" />');
        Search.form.append('<input type="hidden" name="' + cs + data.vals[0].kind + ']' + '" value="' + data.vals[0].val + '" />');
        if(data.vals[0].kind=='min' || data.vals[0].kind=='max'){
            Search.form.append('<input type="hidden" name="' + cs + data.vals[1].kind + ']' + '" value="' + data.vals[1].val + '" />');
        }
    },
    lineParamsToString: function(i, line){
        var data = Search.getLineData(line);
        var cs = 'search[' + i + '][';
        var v = cs + data.vals[0].kind + ']=' + data.vals[0].val;
        v +=  (data.vals[0].kind=='min' || data.vals[0].kind=='max')? '&' 
                +  cs + data.vals[1].kind + ']=' + data.vals[1].val : '';
        return cs +  'col]=' + data.col + '&' + cs + 'bool]=' + data.condition + '&' + v;
    },
    removeLine: function(){
    },
    addLine: function(item){
        var lineHolder = $('<div class="col-12 mt-4 searchFormLine"><div class="row"></div></div>').appendTo(Search.form);
        var line = lineHolder.find('.row');
        if(!item){ item = {bool: '', col: null}; }
        Search.addBoolBlock(line, item.bool);
        Search.addInputBlock(line, Search.data[0], item);
        Search.addColumnBlock(line, Search.data, item.col);
        Search.addSubmitBlock(line);
        if(typeof item.contains != 'undefined'){
            Search.inputAsInput(line, item.contains); // after we have set the column
        }else if(typeof item.exact != 'undefined'){
            Search.inputAsInput(line, item.exact); // module to replace
            Search.inputAsDDN(line, item.exact); // after we have set the column
        }else if(typeof item.min != 'undefined'){
            Search.inputAsInput(line, ''); // module to replace
            Search.inputAsRange(line, item.min, item.max); // after we have set the column
        }else{
            Search.inputAsInput(line, '');
        }
        Search.bindLines();
    },
    addBoolBlock: function(line){
        line.append('<div class="col-1 pl-0 searchBoolBlock">\
                <div class="btn-group w-100">\
                  <button class="btn btn-outline-primary dropdown-toggle w-100" type="button"\
                      id="dropdownMenuButton" data-toggle="dropdown"\
                      aria-haspopup="true" aria-expanded="false">\
                    And\
                  </button>\
                  <input type="hidden" value=""></input>\
                  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">\
                      <a class="dropdown-item" href="#">And</a>\
                      <a class="dropdown-item" href="#">Or</a>\
                      <a class="dropdown-item disabled" href="#">And not</a>\
                  </div>\
                </div>\
              </div>');
    },
    addInputBlock: function(line, col){
        line.append( '<div class="col-6 pl-0 searchInputBlock"></div>' ); 
    },
    setInputBlock: function(line) {
        var col = line.find('.searchColumnBlock button').text();
        var currentType = Search.data[col].types.current == 'default' ? Search.data[col].types.default : Search.data[col].types.current;
        if( currentType == 'input' ){
            Search.inputAsInput(line, '');
        }else if ( currentType == 'list' ){
            Search.inputAsDDN(line, '');
        }else if ( currentType == 'range' ){
            Search.inputAsRange(line, '', '');
        }
    },
    inputAsRange: function(line, min, max){
        var col = line.find('.searchColumnBlock button').text();
        var types = Search.data[col].types;
        var ex = types.input.example;
        line.find('.searchInputBlock').replaceWith('<div class="col-6 form-inline pl-0 searchInputBlock">'
            + '<input type="number" data-kind="min" step="0.0001" min="' + types.input.min + '" max="' + types.input.max + '" '
              + 'class="form-control col-6" placeholder="Example: ' + ex + '" value="' + min + '" required>'
            + '<input type="number" data-kind="max" step="0.0001" min="' + types.input.min + '" max="' + types.input.max + '" '
              + 'class="form-control col-6" placeholder="Example: ' + ex + '" value="' + max + '" required>'
            + '<small class="form-text text-muted addSearchLineHelper">'
            + '<a class="inputTypeInput" href="#">Search exact value</a>'
            + '</small>'
          + '</div>');
        Search.bindLines();
    },
    inputAsInput: function(line, val){
        var col = line.find('.searchColumnBlock button').text();
        var types = Search.data[col].types;
        console.log('inputAsInput', types, types.list);
        var type = types.input.type;
        var ex = types.input.example;
        var switches = (types.list)? '<small class="form-text text-muted inputTypeDDN"><a href="#">Select from Index</a></small>' :
            ((types.range)? '<small class="form-text text-muted inputTypeRange"><a href="#">Set range</a></small>' : '');
        Search.data[col].types.current = 'input';
        if( type == 'str' ){
            line.find('.searchInputBlock').replaceWith('<div class="col-6 pl-0 searchInputBlock">'
                + '<input type="text" data-kind="contains" class="form-control" placeholder="Example: ' 
                + ex + '" value="' + val + '" required>'
                + switches
              + '</div>');
        }else if ( type == 'float' ){
            line.find('.searchInputBlock').replaceWith('<div class="col-6 pl-0 searchInputBlock">'
                + '<input type="number" data-kind="exact" step="0.0001" in="' + types.input.min + '" max="' + types.input.max + '" '
                  + 'class="form-control" placeholder="Example: ' + ex + '" value="' + val + '" required>'
                + switches
              + '</div>');
        }
        Search.bindLines();
    },
    inputAsDDN: function(line, val){
        var col = line.find('.searchColumnBlock button').text();
        
        $.post('', 'list=' + col)
         .done(function(list){ Search.addInputList(line, list, col, val); })
         .fail(function(a,b,c){ console.log(a,b,c); });
    },
    addInputList: function(line, list, col, val){
        Search.data[col].types.current = 'list';
        console.log(Search.data[col]);
        var colName = Search.data[col].reference ? Search.data[col].ref_field : col;
        line.find('.searchInputBlock').replaceWith('<div class="col-6  pl-0 searchInputBlock">'
                + '<div class="btn-group w-100">'
                  + '<button class="btn btn-outline-primary dropdown-toggle w-100 text-right" type="button"'
                    +  'data-toggle="dropdown"'
                    +  'aria-haspopup="true" aria-expanded="false">'
                  + ((val != '')? val : list[0][colName])
                  + '</button>'
                  + '<input type="hidden"  data-kind="exact" value=""></input>'
                  + '<div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton"></div>'
                + '</div>'
                + '<small class="form-text text-muted addSearchLineHelper">'
                + '<a class="inputTypeInput" href="#">Search text contains</a>'
                + '</small>'
              + '</div>');
        var menu = line.find( '.searchInputBlock .dropdown-menu' );
        $.each(list, function(i, item){ menu.append('<a class="dropdown-item" href="#">' + item[colName] + '</a>'); });
        Search.bindLines();
    },
    addColumnBlock: function(line, columns, col){
        line.append('<div class="col-3  pl-0 searchColumnBlock">'
                + '<div class="btn-group w-100 columnDDN">'
                  + '<button class="btn btn-outline-primary dropdown-toggle w-100 text-right" type="button"'
                    +  'data-toggle="dropdown"'
                    +  'aria-haspopup="true" aria-expanded="false">'
                  + '</button>'
                  + '<input type="hidden" value=""></input>'
                  + '<div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuButton"></div>'
                + '</div>'
                + '<small class="form-text text-muted addSearchLineHelper">'
                + '<a class="addSearchLine" href="#">+ Add search row</a> | '
                + '<a class="resetSearch" href="#">Reset form</a>'
                + '</small>'
              + '</div>');
        var menu = line.find( '.searchColumnBlock .dropdown-menu' );
        $.each(columns, function(key, col){ menu.append('<a class="dropdown-item" href="#">' + key + '</a>'); });

        var preselected = (col && col != '') ? col : menu.find(".dropdown-item:first-child").text();

        line.find('.searchColumnBlock button').html( preselected );
        menu.append('<div class="dropdown-divider"></div>');
        menu.append('<a class="dropdown-item remove-search-line" href="#">Remove</a>');
    },
    addSubmitBlock: function(line){
        $('.submitFilesBlock').remove();
        line.append('<div class="col-2 pl-0 submitSearchBlock">\
                <button class="btn btn-primary w-100" type="button">Search</button>\
                <small class="form-text text-muted text-right"><a href="#">Search tips</a></small>\
              </div>\
              <div class="col-12 pt-3 pl-0 submitFilesBlock">\
                <div class="col-10 float-left pr-0 searchFiles"></div>\
                <div class="col-2 float-right pr-0 requestCSV">\
                  <button class="btn btn-outline-primary w-100" type="button">Create CSV</button>\
                </div>\
              </div>');
        var filesHolder = line.find('.searchFiles');
        $.each(Search.files, function(i,sch){
            var str = '';
            $.each( sch.search, function(i, o){
                str += (i!=0) ? o.bool : '';
                str += ' ' + o.col + ' ';
                str += (typeof o.contains != 'undefined') ? 'contains ' + o.contains : ' ';
                str += (typeof o.exact != 'undefined') ? 'exact ' + o.exact : ' ';
            });
            if( sch.filename ){
                filesHolder.append('<small class="form-text"><a href="../saved_searches/' + sch.filename + '.csv">' 
                    + sch.id  + ' '  + str + '(' + sch.count + ') '
                    +  '</a><a class="deleteFile"  data-id="' + sch.id + '" href="#"> X </a></small>');
            }else{
                filesHolder.append('<small class="form-text">' + sch.id  + ' '  + str 
                    +  '<a class="deleteFile" data-id="' + sch.id + '.csv" href="#"> X </a></small>');
            }
        });
    }
}


var Page = {
    init: function(){
        Page.slug = window.__PAGESLUG__;
        Page.state = JSON.parse(window.__PRELOADED_STATE__);
        Page.uploads_state = window.__PRELOADED_STATE__FILES__ ? JSON.parse(window.__PRELOADED_STATE__FILES__) : null;

        if( $(".top-pagination").length != 0 ){ 
            new Pagination( ".top-pagination", Page.state );
        }
        if( $(".uploads-pagination").length != 0 ){ 
            new Pagination(".uploads-pagination", { pagination: Page.uploads_state.uploads_pagination });
        }
        if( $("#index-dropzone").length == 0 ){ return; }

        Page.initDropzone("#index-dropzone", 'index', "Drop INDEX file here", "INDEX", {});
        Page.initDropzone("#pdb-dropzone", 'pdbfile', "Drop .pdb file here", "PDB", {});
        Page.initDropzone("#fasta-dropzone", 'fasta', "Drop .fasta file here", "FASTA", {});
        Page.initDropzone("#amino-dropzone", 'amino', "Drop .fasta for amino acid count", "AMINO", {});

        TableExport(document.getElementById("proteins-table"), {
            headers: false, // (Boolean), display table headers (th or td elements) in the <thead>, (default: true)
            footers: false, // (Boolean), display table footers (th or td elements) in the <tfoot>, (default: false)
            formats: ['xlsx', 'csv', 'txt'], // (String[]), filetype(s) for the export, (default: ['xlsx', 'csv', 'txt'])
            filename: 'proteins', // (id, String), filename for the downloaded file, (default: 'id')
            bootstrap: false, // (Boolean), style buttons using bootstrap, (default: true)
            exportButtons: true, // (Boolean), automatically generate the built-in export buttons for each of the specified formats (default: true)
            position: 'top', // (top, bottom), position of the caption element relative to table, (default: 'bottom')
            ignoreRows: null,  // (Number, Number[]), row indices to exclude from the exported file(s) (default: null)
            ignoreCols: null, // (Number, Number[]), column indices to exclude from the exported file(s) (default: null)
            trimWhitespace: true // (Boolean), remove all leading/trailing newlines, spaces, and tabs from cell text in the exported file(s) (default: false)
        });

        $('#proteins-table .top.tableexport-caption').append(' <a class="btn btn-sm btn-outline-secondary" href="/">Clear results table</a>'
            + ' <a class="btn btn-sm btn-outline-secondary" href="' + window.location + '?delete=1">Delete page</a>'
            + '<nav class="nav nav-pills mt-3" aria-label="Page navigation"><ul class="top-pagination pagination"></ul></nav>');

        if( $("#proteins-table .pagination").length != 0 ){ 
            new Pagination( ".top-pagination", Page.state );
        }

        $('.hbonds-bridges-start').click(function(e){
            e.preventDefault();
            $.post('calculate', 'pageslug=' + Page.slug + '&start=1')
                .done(function(reply){ flashCard.add('success', JSON.stringify(reply)); });
        });
        $('.hbonds-bridges-stop').click(function(e){
            e.preventDefault();
            $.post('calculate', 'pageslug=' + Page.slug + '&stop=1')
                .done(function(reply){ flashCard.add('success', JSON.stringify(reply)); });
        });

       $('#models-start').click(function(e){
            e.preventDefault();
            $.post('swiss', 'pageslug=' + Page.slug + '&start=1')
                .done(function(reply){ flashCard.add('success', JSON.stringify(reply)); });
        });
        $('#models-stop').click(function(e){
            e.preventDefault();
            $.post('swiss', 'pageslug=' + Page.slug + '&stop=1')
                .done(function(reply){ flashCard.add('success', JSON.stringify(reply)); });
        });
    },

    initDropzone: function(id, url, message, paramName, params){
        Page[id] = new Dropzone(id,{
                    url: url,
                    chunking: true,
                    chunkSize: 3*1024*1024,
                    maxFilesize: 1500,
                    forceChunking: false,
                    parallelChunkUploads: false,
                    retryChunks: true,
                    retryChunksLimit: 3,
                    chunksUploaded: function(big_file, done_func){
                        done_func();
                    },
                    sending: function(a,b,formdata){ // in case you want to add data and not override chunk info
                        $.each(params, function(nm,vl){ 
                            formdata.append(nm,vl);
                        });
                        formdata.append('pageslug', Page.slug); // subject to changes
                    },
                    dictDefaultMessage: message,
                    paramName: paramName
        });

        Page[id].on("complete", function(file) { // even chunked file gives it only once
            var data = file.xhr.response;
            if( typeof( data ) == 'string' ){ 
                data = JSON.parse(data); 
            }
            Page.handleUploadResponse(data);
            if('undefined' != typeof(data.page)){
                Page.slug = data.page;
            }
            Page[id].removeFile(file);
        });
    },

    handleUploadResponse: function(data){
        if('undefined' != typeof(data.successes)){
            if('undefined' != typeof(data.successes.inserted_fasta_records_number)
                && data.successes.inserted_fasta_records_number > 0){
                    window.location.reload(true);
            }
            if('undefined' != typeof(data.successes.protein)){
                Page.proteinRow(data.successes.protein);
            }
            if('undefined' != typeof(data.successes.upload)){
                Page.uploadRow(data.successes.upload);
            }
        }
        if('undefined' != typeof(data.errors) && data.errors.length > 0){
            flashCard.add('danger', JSON.stringify(data.errors));
        }
    },
    
    proteinRow: function(row){
        if( $('#'+row.id).length > 0 ){
            $('#'+row.id).replaceWith( Page.getProteinRow(row) );
            return;
        }
        $("#proteins-table tbody").append( Page.getProteinRow(row) );
    },

    getProteinRow: function(row){
        return $('<tr id="' + row.id + '">'
           + '<td>' + row.id + '</td>'
           + '<td>' + row.name + '</td>'
           + '<td>' + row.gene + '</td>'
           + '<td>' + row.species + '</td>'
           + '<td>' + row.len + '</td>'
           + '<td>' + row.qmean + '</td>'
           + '<td>' + row.qmean_norm + '</td>'
           + '<td>' + row.bonds + '</td>'
           + '<td>' + row.bridges + '</td>'
           + '<td>' + row.filename + '</td>'
           + '</tr>');
    },

    uploadRow: function(row){
        if( $('#upload_'+row.id).length > 0 ){
            $('#upload_'+row.id).replaceWith( Page.getUploadRow(row) );
            return;
        }
        $(".uploads-table tbody").append( Page.getUploadRow(row) );
    },

    getUploadRow: function(row){
        return $('<tr id="upload_' + row.id + '">'
           + '<td>' + row.id + '</td>'
           + '<td>' + row.UniProt + '</td>'
           + '<td>' + row.filename + '</td>'
           + '<td>' + row.record + '</td>'
           + '<td>' + row.qmean + '</td>'
           + '<td>' + row.attempts + '</td>'
           + '</tr>');
    }
}

var ProgressBar = {
    set: function(id, percentComplete){
        id = "#" + id + "-progress";
        $(id + ".progress").addClass("show in");
        $(id + ' .progress-bar')
            .css('width', percentComplete +'%')
            .attr('aria-valuenow', percentComplete)
            .html(percentComplete +'%');
        if( percentComplete >= 100 ){
            $(id + ".progress").removeClass("show in");
            $(id + ' .progress-bar').css('width', '0%').attr('aria-valuenow', 0).html('0%');
        }
    }
}


var Socket = {
    ws: null,
    sockets: [],
    url: 'ws://'+document.location.hostname+':13005/',
    last_pong:  Date.now(),  /// important, or there will be loop
    checkInterval: null,
    socketType: 'default',

    ping: function(){
        if( null == Socket.ws ){
            Socket.init();
        }
        if( Date.now() - Socket.last_pong > 30*1000 ){ 
            Socket.reload();
            return;
        }

        /// overprotection for non closing sockets
        var count = 0;
        $.each(Socket.sockets, function(i, sk){ 
            count += Number(sk.readyState == 1);
        });
        if( count > 0 ){
            var gotOne = false;
            $.each(Socket.sockets, function(i, sk){
                if( !gotOne && sk.readyState == 1 ){
                    Socket.ws = sk;
                    gotOne = true;
                }else if(sk.readyState == 1){
                    Socket.ws.send(JSON.stringify('closeme'));
                }
            });
        } /// not sure if it's ever needed


        // state 0 - opening, 1 - ready, 2 - closing, 3 - closed

        if( Socket.ws.readyState == 1 && Date.now() - Socket.last_pong > 1000 ){ 
            Socket.ws.send(JSON.stringify('ping'));
        }
    },
    
    init: function(){
        console.log( 'node init');
        var new_ws = new webSocket(this.url);
        Socket.sockets.push( new_ws );
        new_ws.ID = Socket.sockets.length;
        Socket.ws = new_ws; 
        this.bind_socket();
        if( !this.checkInterval ){  /// hm, might need to be restatrted sometimes
            this.checkInterval = setInterval(Socket.ping, 1000);
        }
    },
    destroy: function() {
        clearInterval(this.checkInterval);
        this.checkInterval = null;
        this.shouldAttemptReconnect = false;
        Socket.ws.close();
        Socket.last_pong = Date.now(); /// important
    },
    reload: function(){
            Socket.destroy();
            Socket.init();
    },
    bind_socket: function(){

        Socket.ws.onopen = function(e){
            console.log( 'node open');
            Socket.ws.last_ping = Date.now(); 
        };

        Socket.ws.onclose = function(e){
            if( Socket.ws && Socket.ws.ID == e.target.ID ){
                if(Socket.ws.readyState == 1){ Socket.ws.send(JSON.stringify('closeme')); }
                Socket.ws.onclose = function () {};
                Socket.ws.close();
                Socket.ws = null;
            }
        };

        // same as onclose
        Socket.ws.onerror = function(e){
            if( Socket.ws && Socket.ws.ID == e.target.ID ){
                if(Socket.ws.readyState == 1){ Socket.ws.send(JSON.stringify('closeme')); }
                Socket.ws.onclose = function () {};
                Socket.ws.close();
                Socket.ws = null;
            }
        };

        Socket.ws.onmessage = function(e){
            Socket.last_pong = Date.now(); 
            if('object' == typeof(e.data)){ 
                var dataObject = e.data;
            }else if( 'string' == typeof(e.data)){ 
                var dataObject = JSON.parse(e.data);
            } else {
                return;
            }


            if( 'object' == typeof(dataObject) ){

                if( 'provideSocketType' == dataObject.type ){
                    Socket.ws.send(JSON.stringify({ 
                        'setSocketType' : Socket.socketType, 
                        'setPage': Page.slug
                    }));
                }else{
                    //console.log(dataObject);
                    Socket.handleUpdate(dataObject);
                }

            }else if(dataObject != 'pong'){

                console.log('not object:', dataObject, typeof(dataObject));

            }else{
                // console.log('pong',  dataObject );
            }
        };
    }, // end of bind socket

    handleUpdate: function(data){
        if('undefined'==typeof(data.sys) && 'undefined'!=typeof(data.progress)){
            // console.log(data.type, data.progress);
            ProgressBar.set(data.type, data.progress);
        }
    }
};


var flashCard = {
    dismiss: function(){
        var this_card = $(this);
        this_card.addClass( 'way-to-the-right' );
        setTimeout(function(){ this_card.remove(); }, 500 );
    },

    add: function( type, note ){
       var box = $('.flash-box');
       var card  = $(
         '<div class="flash-card way-below ' + type + '">\
            <div class="flash-card-icon"><i class="icon3-flash"></i></div>\
            <div class="flash-card-text">' + note + '</div>\
         </div>').appendTo( box );
       setTimeout(function(){ card.removeClass('way-below'); }, 100 );
       card.bind('click', flashCard.dismiss);
       setTimeout(function(){ card.fadeOut(600, function(){ card.remove(); }) }, 45000 );
    }
};


Page.init();
Search.init();
Socket.init();
